import dataclasses, tempfile, unittest, json
from pathlib import Path
import numpy as np
import torch
from branchfrontier.cab import (CABPolicy,action_vector,arm_kernel,arm_distribution,
    feedback_labels,select_arm,default_policies)
from branchfrontier.cab_study import CABStudy
from branchfrontier.cab_fake import FakeCABAdapter
from branchfrontier.cab_gpu import lowfreq_action_basis,CABSD15GPU
from branchfrontier.cab_cli import analyze_rows,generated_grid
from branchfrontier.cab_probe import paired_action_probe

class CABUnitTests(unittest.TestCase):
    def feats(self):
        return np.stack([np.eye(16)[i] for i in range(16)])

    def hist(self,arms=(0,1,2,3),parents=(0,0,0,0),outcomes=(1,-1,1,-1)):
        result=[]
        pol=CABPolicy('test')
        for slot,(a,parent,outcome) in enumerate(zip(arms,parents,outcomes)):
            r0=0.
            lab=feedback_labels(float(outcome),r0,min_novelty=.1,policy=pol)
            result.append(dict(parent=parent,arm=a,slot=slot,
                 reward=float(outcome),labels=lab,novelty=.1))
        return result

    def test_actions_signs_and_kernel(self):
        self.assertTrue(np.array_equal(action_vector(0,4),-action_vector(1,4)))
        self.assertAlmostEqual(arm_kernel(0,0,4,.7),1.)
        self.assertLess(arm_kernel(0,1,4,.7),arm_kernel(0,2,4,.7))

    def test_low_frequency_basis_is_orthonormal(self):
        for d in (1,4,8):
            B=lowfreq_action_basis(d,seed=4).reshape(d,-1)
            self.assertLess((B@B.T-torch.eye(d)).abs().max().item(),1e-4)

    def test_uniform_policy_and_early_warmup(self):
        p=CABPolicy('x',mode='uniform_action')
        prob,diag=arm_distribution(p,0,self.feats(),self.hist(),prompt_id=1,seed=10,slot=4)
        self.assertTrue(np.allclose(prob,np.ones(8)/8))
        self.assertFalse(diag['activated'])
        p=dataclasses.replace(p,mode='contrastive_action',min_observations=10)
        prob,_=arm_distribution(p,0,self.feats(),self.hist(),prompt_id=1,seed=10,slot=4)
        self.assertTrue(np.allclose(prob,np.ones(8)/8))

    def test_positive_and_negative_are_distinct(self):
        hist=self.hist(outcomes=(2,-2,2,-2))
        pol=CABPolicy('x',mode='positive_action',min_observations=1,cross_parent_strength=0.)
        pp,_=arm_distribution(pol,0,self.feats(),hist,prompt_id=1,seed=1,slot=4)
        nn,_=arm_distribution(dataclasses.replace(pol,mode='negative_action'),0,self.feats(),hist,prompt_id=1,seed=1,slot=4)
        self.assertGreater(pp[0],pp[1]);self.assertGreater(nn[0],nn[1]);self.assertFalse(np.allclose(pp,nn))
        cb,info=arm_distribution(dataclasses.replace(pol,mode='contrastive_action'),0,self.feats(),hist,prompt_id=1,seed=1,slot=4)
        self.assertGreater(cb[0],cb[1]);self.assertGreater(info['tv_from_uniform'],0)

    def test_no_future_feedback_leak(self):
        with self.assertRaisesRegex(ValueError,'Future'):
            arm_distribution(CABPolicy('x'),0,self.feats(),self.hist(),prompt_id=1,seed=1,slot=3)

    def test_no_signal_no_forced_guidance(self):
        p=CABPolicy('x',mode='contrastive_action',min_observations=1)
        hist=[dict(parent=0,arm=0,slot=0,labels=dict(positive=0.,negative=0.,redundant=0.))]
        prob,diag=arm_distribution(p,0,self.feats(),hist,prompt_id=0,seed=0,slot=1)
        self.assertFalse(diag['activated']);self.assertTrue(np.allclose(prob,np.full(8,1/8)))

    def test_feedback_margin_is_abstention(self):
        p=CABPolicy('x');x=feedback_labels(.02,0.,.1,p)
        self.assertEqual(x['positive'],0);self.assertEqual(x['negative'],0)
        self.assertGreater(feedback_labels(-.30,0.,.1,p)['negative'],0.)

    def test_reward_shuffle_can_change_decisions(self):
        p=CABPolicy('x',mode='contrastive_action',min_observations=1)
        h=self.hist(arms=(0,1,2,3,4,5),parents=(0,0,0,0,0,0),
                    outcomes=(2,-2,2,-2,-2,2))
        normal,_=arm_distribution(p,0,self.feats(),h,prompt_id=1,seed=7,slot=6)
        changed=False
        for seed in range(25):
            shuffle,_=arm_distribution(dataclasses.replace(p,mode='shuffled_negative'),0,self.feats(),h,prompt_id=1,seed=seed,slot=6)
            changed|=not np.allclose(normal,shuffle)
        self.assertTrue(changed)

    def test_deterministic_action_draw(self):
        p=CABPolicy('x',mode='contrastive_action',min_observations=1)
        a=select_arm(p,0,self.feats(),self.hist(),1,2,4)
        b=select_arm(p,0,self.feats(),self.hist(),1,2,4)
        self.assertEqual(a,b)

    def test_budget_all_default_and_grid(self):
        for p in default_policies()+generated_grid():self.assertLessEqual(p.validate().cold_nfe(),2600)
        self.assertEqual(CABPolicy('x').cold_nfe(),2580)
        with self.assertRaises(ValueError):CABPolicy('over',branches=20).validate()

    def test_fake_end_to_end_with_resume_and_controls(self):
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            specs=['reward14','cab_uniform14','cab_positive14','cab_negative14',
                   'cab_contrastive14','cab_shuffle_negative14']
            rows=s.run_unit('toy',1,500,specs,check_replay=True)
            self.assertEqual({r['method'] for r in rows},set(specs))
            self.assertIn('cab_action_avg_tv',rows[2])
            n=a.nfe
            s.run_unit('toy',1,500,specs,check_replay=True)
            self.assertEqual(a.nfe,n)
            conf=json.loads(next(Path(d).glob('unit_*/policy_cab_contrastive14.json')).read_text())
            self.assertEqual(len(conf['traces']),14)
            parents=[h['parent'] for h in conf['parent_history']]
            reward=json.loads(next(Path(d).glob('unit_*/policy_reward14.json')).read_text())
            self.assertEqual(parents,[h['parent'] for h in reward['parent_history']])
            self.assertTrue(any(q['selection']['effective_history_count']>=3 for q in conf['traces']))
            decision=analyze_rows(s.all_rows,Path(d)/'analysis',minimum_prompts=4)
            self.assertEqual(decision['status'],'INCOMPLETE_TRAIN')

    def test_action_cache_key_no_collisions(self):
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            s.run_unit('toy',1,500,['cab_uniform14','cab_contrastive14'],check_replay=False)
            files=list(Path(d).glob('unit_*/action_children/*.pt'))
            self.assertGreaterEqual(len(files),14)
            keys=[f.stem for f in files]
            self.assertEqual(len(keys),len(set(keys)))


    def test_paired_probe_counts_exact_nfe_and_response(self):
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            before=a.nfe
            summary=paired_action_probe(s,'toy',1,500,parents=2,checkpoint=30,
                                         arms=(0,1),strength=2.)
            self.assertEqual(len(summary['rows']),4)
            # Roots 2600 + 2 neutral and 4 acted suffixes, each with 70 NFE.
            self.assertEqual(a.nfe-before,2600+6*70)
            self.assertEqual(summary['actual_physical_nfe'],6*70)
            self.assertTrue(any(abs(r['paired_reward_delta'])>1e-6 for r in summary['rows']))


    def test_real_gpu_noise_modifier_without_loading_gpu(self):
        # Construct only the CPU noise path without initializing model or CUDA.
        a=object.__new__(CABSD15GPU)
        a.root_seed=500;a.prompt_id=1;a.eta=1.;a._cab_action=None;a._cab_basis_cache={}
        base=a._noise(10001,30,'fork')
        a._cab_action=dict(slot=10001,checkpoint=30,arm=0,strength=2.,window=6,dim=4,seed=2031)
        plus=a._noise(10001,30,'fork')
        a._cab_action['arm']=1
        minus=a._noise(10001,30,'fork')
        self.assertAlmostEqual(float((plus-base).norm()),2.,places=4)
        self.assertLess(float((plus+minus-2*base).abs().max()),1e-5)
        self.assertTrue(torch.equal(a._noise(10001,36,'fork'),CABSD15GPU._noise(a,10001,36,'fork')))
        a._cab_action=None
        self.assertTrue(torch.equal(a._noise(10001,30,'fork'),base))

    def test_adapter_zero_action_is_equal_to_fork_fake(self):
        a=FakeCABAdapter();a.bind('toy',1,500)
        z,_=a.full_roots([0],capture=(30,))
        base=a.fork(z,[99],30)
        acted=a.fork_action(z,[99],30,arm=0,strength=0.,window=6)
        self.assertTrue(torch.equal(base,acted))

    def test_zero_action_equals_reward_only_same_tapes(self):
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            s.run_unit('toy',1,500,['reward14','cab_zero14'],check_replay=False)
            root=[r for r in s.all_rows if r['method']=='reward14' and r['selector']=='top_ir'][0]
            zero=[r for r in s.all_rows if r['method']=='cab_zero14' and r['selector']=='top_ir'][0]
            for metric in ('best_ir','mean_top16_ir','clip_distance'):
                self.assertAlmostEqual(float(root[metric]),float(zero[metric]),places=7)

    def test_paired_arm_feedback_is_same_noise_action_effect(self):
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            s.run_unit('toy',1,500,['cab_pair_contrastive7','cab_pair_uniform7'],check_replay=False)
            folder=next(Path(d).glob('unit_*'))
            pair=json.loads((folder/'policy_cab_pair_contrastive7.json').read_text())
            self.assertEqual(pair['cold_nfe'],2580)
            self.assertEqual(len(pair['traces']),7)
            for t in pair['traces']:
                self.assertEqual(t['feedback_reference_type'],'paired_same_tape_neutral')
                self.assertAlmostEqual(t['labels']['advantage'],t['reward']-t['neutral_reward'],places=7)
                self.assertIsNotNone(t['neutral_reward'])
            pair_rows=[r for r in s.all_rows if r['selector']=='top_ir' and r['method']=='cab_pair_contrastive7']
            self.assertEqual(len(pair_rows),1)
            self.assertEqual(pair_rows[0]['branches'],14)
            self.assertEqual(pair_rows[0]['cold_reward_scores'],30)
            self.assertEqual(pair_rows[0]['cab_feedback_type'],'paired')

    def test_paired_analysis_uses_only_top_reward_selector(self):
        # Regression: multiple selector rows used to overwrite method pairs
        # and silently compare diversity-slack outcomes while labeled top_ir.
        rows=[]
        for pid in range(4):
            for selector in ('top_ir', 'diversity_slack_0.05'):
                for method in ('bon26','reward14','cab_uniform14','cab_positive14',
                               'cab_shuffle_negative14','cab_contrastive14'):
                    base=0. if method in ('bon26','reward14','cab_uniform14') else .02
                    if method=='cab_contrastive14':base=.32
                    if selector!='top_ir':base=-99. if method=='cab_contrastive14' else 99.
                    rows.append(dict(prompt_id=pid,seed=101,method=method,selector=selector,
                        best_ir=base,mean_top16_ir=base,clip_distance=base/10.,
                        cab_action_active_rate=1.0,cab_action_avg_tv=.20,
                        cab_negative_observations=4))
        with tempfile.TemporaryDirectory() as d:
            a=analyze_rows(rows,Path(d),bootstrap=100,minimum_prompts=4)
            rows.reverse()
            b=analyze_rows(rows,Path(d),bootstrap=100,minimum_prompts=4)
            def point(q):
                return next(x for x in q['candidates'] if x['method']=='cab_contrastive14')
            self.assertAlmostEqual(point(a)['mean_delta_vs_reward_only'],.32)
            self.assertAlmostEqual(point(b)['mean_delta_vs_reward_only'],.32)
            self.assertGreater(point(a)['delta_vs_shuffled_negative'],0)

    def test_hybrid_fresh_images_not_in_action_feedback_archive(self):
        from branchfrontier.cab_study import novelty_to_archive
        from branchfrontier.core import normalized
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            roots,folder=s.roots('toy',1,500)
            s.run_policy(s.catalog['cab_contrastive10b3f'],roots,folder,1,500)
            obj=json.loads((folder/'policy_cab_contrastive10b3f.json').read_text())
            entry=obj['traces'][0]
            child_id=next(folder.glob('action_children/action_*.pt'))
            # Restore selected slot0 child by recorded arm and parent, not a file glob order.
            from branchfrontier.cab_study import _sha_json
            pol=s.catalog['cab_contrastive10b3f']
            params=dict(parent=entry['parent'],slot=0,checkpoint=pol.fork_index,
                arm=entry['arm'],strength=round(pol.action_strength,8),window=pol.action_steps,
                dim=pol.action_dim,basis_seed=pol.action_basis_seed)
            rec=torch.load(folder/'action_children'/f'action_{_sha_json(params)}.pt',
                           map_location='cpu',weights_only=False)
            reference=[roots['features'][i] for i in range(16)
                if roots['scores'][i]>=np.quantile(roots['scores'][:16],.75)]
            expected=novelty_to_archive(rec['feature'],reference)
            self.assertAlmostEqual(entry['novelty'],expected,places=6)

    def test_cab_candidates_supported_in_external_semantic_audit(self):
        from branchfrontier.human_eval import semantic_bounds
        with tempfile.TemporaryDirectory() as d:
            a=FakeCABAdapter();s=CABStudy(a,out=d,budget=2600,N=16,selectors=(0.,))
            s.run_unit('toy',1,500,['cab_uniform14'],check_replay=False)
            label_path=Path(d)/'semantic.csv'
            label_path.write_text('prompt_id,image_sha,semantic_pass\n')
            output=semantic_bounds(Path(d)/'all_rows.csv',label_path,
                                   Path(d)/'semantic_bounds.csv')
            self.assertEqual(len(output),3)
            self.assertTrue(all(x['unknown']==16 for x in output))

if __name__=='__main__':unittest.main()
