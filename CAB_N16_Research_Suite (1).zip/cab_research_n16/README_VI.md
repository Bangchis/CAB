# Contrastive Adaptive Branching (CAB) — SD1.5 N16 research prototype

**Trạng thái:** Source + 2 Jupyter notebooks, kèm kiểm thử CPU; **CHƯA chạy SD1.5/T4 CUDA trong môi trường tạo gói**. Các kết quả `FakeCABAdapter` là dữ liệu tổng hợp, **không phải** neural evidence.

## 1. Câu hỏi khoa học cần chứng minh

Từ pilot TRAIN8×2 do bạn cung cấp, reward-only branching đã cho tín hiệu Best ImageReward tăng so với BoN26 nhưng CLIP diversity giảm. Những biến thể local covariance/Sinkhorn/softmax hướng từng không hơn scouting. Do vậy CAB **không phải** phép trung bình correction. CAB sử dụng terminal reward của các child trước đây để chọn **kiểu stochastic noise action** của child tiếp theo, có cả reward gain và loss/duplicate.

Bản có thể chạy này kiểm tra giả thuyết **âm có đóng góp ngoài dương**, không khẳng định novelty hoặc superiority trước khi có fresh evaluation.

## 2. Thiết kế toán học (cụ thể hơn một parent score có negative penalty)

Với 16 independent roots `x_i`, sinh và chấm ảnh root (được phép dùng terminal root reward vì đã trả chi phí full100). Lưu checkpoint ở completed steps 20,30,40. CAB chọn **đúng parent theo policy reward-only** để giữ cố định tác động donor scheduling. Ở fork index30, trong 6 bước noise variance đầu của suffix, chọn action `a` thuộc 8 vector `±e_1,...,±e_4` và thay innovations:

`eps'_step = eps_step + action_strength * B[a]`, trong đó `B[a]` là low-frequency noise basis orthonormal trên `[4,64,64]`, norm L2=1. Các innovations về sau không đổi. Mỗi `slot` dùng base noise tape giống nhau giữa các method, independent theo slot. **Tác động này là thay innovation distribution có kiểm soát, KHÔNG giữ chính xác Gaussian prior conditional on action.** Tổng KL danh nghĩa của các noise shift là `0.5 * action_strength^2 * active_steps`; không phải image KL.

Sau child `j`, log **terminal** reward và feature CLIP:

- `gain_j = r(child_j) - r(original_root[parent_j])`, chỉ là relative ImageReward, không phải semantic-success label.
- `positive_j = clip((gain_j-good_margin)/feedback_scale,0,1)`.
- `negative_j = clip((-gain_j-bad_margin)/feedback_scale,0,1)`.
- `duplicate_j`: penalty nếu child rất giống một terminal candidate chất lượng cao đã có.

Tại mỗi parent `i` và *before* child `j`, kernel action similarity `K(a,a_j)` và CLIP parent proximity lấy weighted positive/negative evidence từ **các child đã chạy trước**:

`Q_i(a) ∝ exp(beta*pos_i(a) - gamma*neg_i(a) - xi*duplicate_i(a))`, rồi trộn exploration floor uniform. Có prior pseudo-count, min_observations và regularization. Không truy cập reward tương lai; nếu feedback không có tín hiệu, phân phối uniform.

**Lưu ý nguyên lý:** vì action được chọn *trước* khi thấy noise mới, chỉ hoán vị dấu của một Gaussian bằng phép biến đổi bảo toàn measure sẽ không tạo khác biệt phân phối đầu ra giữa các action. Vì vậy probe dùng mean shifts có KL ghi sổ. Muốn bảo toàn prior chính xác phải đổi formulation (ví dụ dùng action phụ thuộc noise đã quan sát) chứ không khẳng định miễn phí.

### 2.1 CAB-Paired: thêm nhánh đo hiệu quả *thật của action* (khuyến nghị chạy sau smoke)

Một vấn đề của CAB thường: `gain = R(child action) − R(original root)` dùng **hai suffix noise khác nhau**, nên không thể kết luận phần giảm reward là do action. **CAB-Paired** tạo mỗi cặp từ *cùng parent, cùng checkpoint, cùng suffix-noise tape*:

`ΔR_action = R(arm_shifted_child) − R(same_tape_neutral_child)`.

Như vậy negative label đo tác động của action trên cùng continuation, không chỉ sự khác biệt so với một ảnh root may mắn. Mỗi cặp cần **hai lần denoising**, đều là output cuối hợp lệ và có trong pool. Để giữ ngân sách:

`16 roots ×100 +7 slots×2 continuations×70 = 2580 sample-NFE`, tạo **30 terminal images**.

Các controls cùng ngân sách: `cab_pair_uniform7`, `cab_pair_positive7`, `cab_pair_negative7`, `cab_pair_contrastive7`, `cab_pair_shuffle7` và `reward14`. CAB-Paired có 7 action decisions, không phải 14; ít dữ liệu hơn có thể làm action policy khó học. **Không có bảo đảm CAB-Paired thắng reward-only hoặc BoN26.**

## 3. Đối chứng cần thiết

| Method | Vai trò | So sánh công bằng |
|---|---|---|
| `bon26` | 26 seeds độc lập ×100 | 2600 NFE, chọn Top16 |
| `reward14` | Existing reward-only donor branching, unmodified Gaussian suffix | 1600 +14×70=2580 |
| `uniform14` | Donor không theo reward | 2580 |
| `adaptive14` | Negative/success heuristic của runner cũ **trên parent** | 2580 |
| `cab_uniform14` | **Cùng donor schedule CAB**, noise code random uniform | 2580 |
| `cab_positive14` | Học positive action evidence, không dùng negative | 2580 |
| `cab_negative14` | Chỉ tránh negative actions | 2580 |
| `cab_contrastive14` | Positive+negative action memory | 2580 |
| `cab_shuffle_negative14` | Positive thật + negative labels hoán vị | 2580 |
| `cab_zero14` | Action strength =0; phải trùng terminal reward-only tại cùng tape | 2580 |
| `cab_pair_contrastive7` | Negative feedback đo bằng paired neutral/action cùng tape | 2580 |

Tất cả chọn top16 từ **chính pool 16 root + 14 children** (30 candidates). BoN26 chọn Top16 từ 26 independent candidates. Chọn ảnh bằng cùng selector và cùng CLIP evaluator. CB/Fresh trên thư mục runs riêng. Run thực tế chia cache; **cold NFE của mỗi method không miễn phí root/scouting**.

**CAB không thể được gọi là cải thiện nhờ negative feedback nếu chỉ thắng BoN:** phải hơn `cab_positive14` và `cab_shuffle_negative14`, ngoài các `reward14` và `cab_uniform14`.

## 4. GPU setup

Giải nén ZIP, mở notebook `notebooks/CAB_N16_GPU.ipynb` trên T4/CUDA. Đi theo notebook để cài requirements trên một môi trường CUDA có PyTorch phù hợp; không cài vào TPU venv frozen. Các mẫu CPU có thể chạy trong bất kỳ môi trường đã cài `numpy torch pillow`.

```bash
cd cab_research_n16
python -m unittest discover -s tests -v
python -m branchfrontier.cab_cli plan \
  --prompts configs/TRAIN_PROMPTS_TEMPLATE.json --stage smoke \
  --seeds 2026110101 --out runs/CAB_PLAN_ONLY
```

**Chú ý:** Template chỉ gồm hai TRAIN prompts mẫu, không phải manifest 8 prompt thật của bạn. Thay bằng TRAIN8 thực tế có các khóa `prompt_id`, `split: TRAIN`, `prompt`. Dùng seed mới và output path mới; không thay file trong một campaign đã khóa.

### Smoke neural (chi phí thật; GPU phải có model/weights)

```bash
python -m branchfrontier.cab_cli run \
  --prompts /path/to/TRAIN8.json --stage smoke \
  --seeds 2026110101 --max-units 1 \
  --out runs/cab_smoke
```

Gồm `reward14`, `cab_uniform14`, `cab_contrastive14`. Root26 được sinh cùng nhau; zero-update replay từ checkpoints được xác minh; child tiếp tục bằng DDIM100 gốc.

### Probe kiểm tra action có thật sự làm ảnh thay đổi

Notebook có cell `RUN_ACTION_PROBE=False` mặc định. Khi bật: lấy 2 root, một noise tape/parent, thử `no_action`, `+arm`, `−arm` và đo **paired reward delta**, CLIP distance, terminal RMS. Chi phí physical bổ sung = `2 parents ×3 suffix×70 =420` NFE, **không tính là evidence thắng BoN**. Nên chạy probe trước pilot; nếu magnitude/signal không rõ, dừng CAB trước khi tăng negative strengths.

### Pilot TRAIN (explicit approve)

```bash
python -m branchfrontier.cab_cli run \
  --prompts /path/to/TRAIN8.json --stage pilot --approve-pilot \
  --seeds 2026110101,2026110102 --max-units 16 \
  --out runs/cab_pilot --bootstrap 10000 --min-prompts 4
```

`--stop-on-futility` nếu muốn dừng giữa prompts **sau khi đủ distinct prompts và hoàn thành seed-block**. Đây là exploratory gate, không phải power analysis. Không bao giờ tự chạy reserved/TEST.

### Offline results

```bash
python -m branchfrontier.cab_cli analyze \
 --results runs/cab_pilot/all_rows.csv --out runs/cab_pilot/review \
 --bootstrap 20000
```

Xem `paired_controls.csv`, `CAB_DECISION.json`, `policy_*.json` (arm probabilities, feedback history) và các gallery top16.

## 5. Sweep tối thiểu trước, rộng sau

1. **Action effect probe:** strength2, window6, 2 parents. Cần output đổi đáng kể hơn nhiễu/cast (không dùng nó để kết luận reward gain chung).
2. **Pilot 8 methods**: chỉ so cách học positive vs negative ở `strength=2`, fork30. Theo dõi activation rate, action probability TV vs uniform, negative count, joint reward/diversity.
3. **Conditional strength sweep**: chỉ mở nếu CAB vs uniform-action có tín hiệu. Giữ checkpoint30: `action_strength ∈ {1,2,4}`, mỗi strength có **uniform + positive** controls giống hệt action space; negative strength chỉ thử `0.5,1,2` trên các strength qua gate. Đừng chạy 54 configs tự động.
4. **Conditional checkpoint sweep**: fork20 với12 branches, fork40 với16 branches; method & matched uniform controls chạy cùng fork. NFE=2560 cho hai lịch này. Không đổi checkpoint và scale cùng một lượt nếu chưa cần.
5. **Hybrid exploration**: 10 branches +3 fresh seeds, cold NFE=2600; so `cab_contrastive10b3f` với `cab_uniform10b3f` và `hybrid10_reward`.

Để xuất toàn bộ **54 config definitions** (không chạy):

```bash
python - <<'PY'
from branchfrontier.cab_cli import generated_grid
import json
from dataclasses import asdict
with open('configs/SWEEP54_LOCKED.json','w') as f:
    json.dump([asdict(p) for p in generated_grid()],f,indent=2)
print(len(generated_grid()))
PY
```

Chạy một subset có tên predeclared, ví dụ:

```bash
python -m branchfrontier.cab_cli run --stage sweep --approve-expensive \
  --methods cab_uniform_cp30_s1,cab_positive_cp30_s1,cab_cp30_s1_neg1 \
  --prompts /path/to/TRAIN8.json --seeds 2026110103 \
  --max-units 4 --out runs/cab_sweep_s1
```

### CAB-Paired pilot có đối chứng thật

```bash
python -m branchfrontier.cab_cli plan --stage paired \
  --prompts /path/to/TRAIN8.json --seeds 2026110101 --out runs/paired_plan

# Có GPU + sau khi kiểm tra plan: 7 paired slots/method, mỗi neutral tính NFE thật
python -m branchfrontier.cab_cli run --stage paired --approve-expensive \
  --prompts /path/to/TRAIN8.json --seeds 2026110101,2026110102 \
  --max-units 16 --out runs/paired_dev
```

Trong báo cáo xem `cab_feedback_type=paired`, `neutral_reward` và `feedback_reference_type=paired_same_tape_neutral`. Chú ý: chỉ dữ liệu development, không dùng reserved/TEST.

**Không** dùng pilot/test đã nhìn để chọn random seeds có lợi; không thay thresholds về sau rồi xem đó là confirmation.

## 6. Metric & gates

- `best_ir`, `mean_top16_ir`, `clip_distance`, `selected_branch_count`, paired Δ so BoN26 **và** reward14.
- `CAB minus positive-only`, `CAB minus negative-shuffled`, `CAB minus uniform-action` trên cùng prompts/seeds. Ngay cả khi CAB thắng BoN vẫn có thể fail phần negative novelty.
- `cab_action_active_rate`, `cab_action_avg_tv`, số observations positive/negative, offspring counts, action-code frequency.
- Outputs selected Top16 có `diversity_slack_0.02,0.05` chạy offline trên cùng candidate pool; không đồng nhất output selection với cải thiện generator.
- Gate thử nghiệm: ít nhất 4 TRAIN prompts, Δmean IR CAB vs reward-only≥0.03, Δbest vs BoN26≥0.03, ΔCLIP vs BoN26≥0.002; negative reward bonus vs positive-only và shuffled≥0.015, **hoặc** CLIP diversity bonus≥0.002 với IR không giảm quá0.01, `active>=0.15`, `TV>=0.02`. Đây chỉ là **ngưỡng đầu tư compute** chưa có statistical confirmation.
- CLIP cosine distance KHÔNG phải semantic success; nếu muốn claim đồng thời quality+diversity cần chấm một rubric semantic khác hoặc blind human review. UNKNOWN phải được giữ như UNKNOWN.

## 7. Compute/causality/caching & những giới hạn

- Root 26×100 được sinh vật lý một lần trên backend GPU manual DDIM. Mọi policy chỉ được xem 16 root đầu và child trước đó của **chính policy đó**. Fresh root extra chỉ dùng cho final candidate pool.
- `CAB_action` và `CAB_uniform` chạy cùng parent schedule, child-slot base noise streams, checkpoint30, noise amplitude/action count; parent đổi chỉ khi method có parent policy khác.
- Các child được cache theo `(prompt, seed, parent, slot, checkpoint, arm, strength, window, basis_seed)`; không tiết kiệm sai cold NFE.
- Cùng model revision/CUDA scheduler nhưng **không bitwise tương đương** standalone GPU `pipe(generator=...)` trong notebook BoN cũ; chính BoN26 trong package này là đối chứng hợp lệ.
- Negative labels là **relative ImageReward**, không được suy thành prompt semantic failure. Học hướng action từ rất ít child có thể suy biến uniform; hành động âm của một parent/time có thể khác hoàn toàn parent/time khác. Cross-parent pooling được giới hạn bởi CLIP feature similarity.
- Kết quả CPU fake chỉ xác thực kỹ thuật. Chưa có pretrained GPU confirmation, chưa chứng minh CAB tốt hơn bất kỳ baseline nào.

## 8. Các file quan trọng

- `notebooks/CAB_N16_GPU.ipynb`: chạy và plan trên T4.
- `notebooks/CAB_Offline_Review.ipynb`: paired review, biểu đồ reward–diversity, selection slack, logs.
- `branchfrontier/cab.py`: action-conditioned positive/negative feedback và sweep configs.
- `branchfrontier/cab_gpu.py`: low-frequency noise modification, chính các innovation steps của DDIM.
- `branchfrontier/cab_study.py`: checkpoint cache, online CAB study, metric/report.
- `branchfrontier/cab_probe.py`: paired action/no-action true-suffix test.
- `branchfrontier/cab_cli.py`: plan, staged training/pilot/sweep, stop rules, analysis.
- `tests/test_cab.py`: CPU mechanism tests.

## 9. Kiểm toán & cảnh báo diễn giải (bản phát hành mới)

- Phần **paired contrasts đã được sửa** để chỉ so các hàng `selector=top_ir`; trước đó các hàng `diversity_slack` có thể ghi đè, làm sai tên metric của báo cáo. Selector-sweep offline là phân tích riêng.
- Với hybrid fresh seeds, negative/novelty memory **không được nhìn trước** fresh images; chúng chỉ có trong final pool.
- External `semantic_bounds` hỗ trợ cả `children/` lẫn `action_children/`; `UNKNOWN` không tự thành pass.
- Cặp CAB-Paired đo tác động của action so với neutral *cùng noise*; CAB thường chỉ có reward **root-relative** và không chứng minh action gây ra failure.
- Một số controls được bổ sung cùng checkpoint và cùng số child: `cab_positive10b3f`, `cab_shuffle10b3f`, `cab_positive_cp20/40`, `cab_shuffle_cp20/40`. Không được so hybrid/timing với positive-only cp30 vì khác budget.
- Phân biệt `cold_nfe`, `cold_reward_scores`, `physical NFE` sau cache và `action shift KL`. Ngoài NFE còn có VAE/CLIP/ImageReward và CUDA wall.
- Với action_dim4 và 14 slots, tín hiệu negative có thể không đủ dày cho policy học. Luôn kiểm tra `mean_tv_from_uniform` và paired action probe; nếu TV≈0 thì âm/dương **chưa thực sự điều khiển sampling**.
