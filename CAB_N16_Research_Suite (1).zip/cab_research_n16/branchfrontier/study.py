"""Full-execution fixed-budget branching experiment with cache & controlled offline selector sweeps.
The same 26 independent root seeds serve as BoN26; branching policies see only the FIRST 16
before choosing donors, plus their own observed offspring rewards.
"""
from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
import json,hashlib,io,time,csv,math
from PIL import Image,ImageDraw
import numpy as np
import torch
from .core import (Policy,stable_seed,policy_manifest,stage_specs,cold_nfe,select_reward,
    select_diversity_with_reward_guard,selection_stats,choose_parent,paired_cluster_bootstrap)


def jdump(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf-8')
    tmp.replace(path)


def csv_write(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:return
    fields=sorted(set().union(*[r.keys() for r in rows]))
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)


def digest(s):return hashlib.sha256(str(s).encode()).hexdigest()[:16]


def image_bytes(im):
    b=io.BytesIO();im.save(b,format='PNG');return b.getvalue()


def png_sha(im):return hashlib.sha256(image_bytes(im)).hexdigest()


def save_gallery(pool,indices,path,side=160):
    '''Contact sheet for human auditing; does not affect any selection.'''
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    sheet=Image.new('RGB',(4*side,4*(side+35)),'white');draw=ImageDraw.Draw(sheet)
    for j,i in enumerate(indices[:16]):
        q=pool[i];x=(j%4)*side;y=(j//4)*(side+35)
        sheet.paste(q['image'].convert('RGB').resize((side,side)),(x,y))
        draw.text((x+3,y+side+3),f"{j+1}: {q['reward']:+.3f}",fill='black')
        draw.text((x+3,y+side+18),q['kind'][:22],fill='black')
    sheet.save(path,quality=90)
    return path


class Study:
    def __init__(self,adapter,out='runs/branch_frontier',budget=2600,N=16,
                 selectors=(0.,.02,.05,.1),quality_threshold=None,novelty_threshold=.08):
        if budget!=2600 or N!=16:raise ValueError('This study locks BoN26 matching: budget=2600,N=16')
        self.a=adapter;self.out=Path(out);self.out.mkdir(parents=True,exist_ok=True)
        self.budget=budget;self.N=N;self.slacks=tuple(float(x) for x in selectors)
        if min(self.slacks)<0:raise ValueError('bad slack')
        self.quality_threshold=quality_threshold;self.novelty_threshold=novelty_threshold
        self.all_rows=[];self.raw_metrics=[];self.physical_nfe_at_init=getattr(adapter,'nfe',0)
        existing=self.out/'all_rows.csv'
        if existing.exists():
            with existing.open(newline='',encoding='utf-8') as f:
                self.all_rows=list(csv.DictReader(f))
        self.catalog={p.name:p for p in policy_manifest()}

    def _unit_folder(self,prompt_id,seed,prompt):
        return self.out/f'unit_{int(prompt_id):03d}_{int(seed)}_{digest(prompt)}'

    def roots(self,prompt,prompt_id,seed):
        a=self.a;a.bind(prompt,prompt_id,root_seed=seed)
        folder=self._unit_folder(prompt_id,seed,prompt);folder.mkdir(parents=True,exist_ok=True)
        cached=folder/'roots.pt';meta=folder/'roots.json'
        expected=dict(prompt=prompt,prompt_id=int(prompt_id),seed=int(seed),revision=a.revision,
                      model_id=a.model_id,feature_mode=a.feature_mode,
                      feature_model=a.feature_encoder.model_id,steps=a.steps)
        if cached.exists() and meta.exists():
            given=json.loads(meta.read_text())
            if any(given.get(k)!=v for k,v in expected.items()):
                raise RuntimeError('Cached root configuration mismatch; use new output path')
            data=torch.load(cached,map_location='cpu',weights_only=False)
            scores=np.load(folder/'root_scores.npy');features=np.load(folder/'root_features.npy')
            images=[Image.open(folder/f'root_{i:02d}.png').convert('RGB') for i in range(26)]
            if len(scores)!=26 or len(data['final'])!=26 or features.shape[0]!=26:
                raise ValueError('Corrupted cache')
        else:
            beg=a.nfe
            final,checkpoints=a.full_roots(list(range(26)),capture=(20,30,40))
            if a.nfe-beg!=2600:raise AssertionError('Expected 26x100 NFE roots')
            images,scores,features=a.finish(final)
            if len(images)!=26:raise AssertionError('roots 26 expected')
            data=dict(final=final.detach().cpu(),checkpoints=checkpoints)
            torch.save(data,cached);np.save(folder/'root_scores.npy',scores);np.save(folder/'root_features.npy',features)
            for i,im in enumerate(images):im.save(folder/f'root_{i:02d}.png')
            jdump(meta,dict(**expected,nfe=2600,root_sha=[png_sha(im) for im in images],
                completed_at=time.strftime('%Y-%m-%dT%H:%M:%S')))
        roots=dict(**data,images=images,scores=np.asarray(scores,float),features=np.asarray(features,float))
        if not (self.a.feature_mode=='CLIP' or self.a.feature_mode=='PIXEL_DEBUG'):
            raise ValueError('Unsupported feature mode')
        return roots,folder

    def replay(self,roots,checkpoints=(30,)):
        return {k:float(self.a.replay_check(roots,cp=k,ids=(0,1,2,3))) for k in checkpoints}

    def _candidate(self,which,idx,roots):
        return dict(id=f'{which}_{idx}',kind=which,parent=None,root_id=int(idx),
            reward=float(roots['scores'][idx]),feature=np.asarray(roots['features'][idx],float),
            image=roots['images'][idx])

    def _branch(self,parent,slot,checkpoint,roots,folder,seed,prompt_id):
        d=folder/'children';d.mkdir(exist_ok=True)
        stem=f'cp{checkpoint:03d}_slot{slot:03d}_parent{int(parent):02d}'
        tensor_file=d/f'{stem}.pt';image_file=d/f'{stem}.png'
        if tensor_file.exists() and image_file.exists():
            record=torch.load(tensor_file,map_location='cpu',weights_only=False)
            if (record['parent'],record['slot'],record['checkpoint'])!=(parent,slot,checkpoint):
                raise RuntimeError('Branch cache identity mismatch')
            im=Image.open(image_file).convert('RGB')
            feat=np.asarray(record['feature'],dtype='float32')
            score=float(record['reward']);actual_nfe=0
        else:
            start=roots['checkpoints'][checkpoint][parent:parent+1].clone()
            before=self.a.nfe
            last=self.a.fork(start,[10_000+slot],checkpoint=checkpoint)
            actual_nfe=self.a.nfe-before
            if actual_nfe!=100-checkpoint:raise AssertionError(f'Bad fork NFE {actual_nfe}')
            ims,rewards,features=self.a.finish(last)
            im=ims[0];score=float(rewards[0]);feat=np.asarray(features[0],dtype='float32')
            im.save(image_file)
            torch.save(dict(parent=int(parent),slot=int(slot),checkpoint=int(checkpoint),
                reward=score,feature=feat,terminal=last[0].detach().cpu(),
                prompt_id=int(prompt_id),seed=int(seed),image_sha=png_sha(im)),tensor_file)
        return dict(id=stem,kind='branch',parent=int(parent),slot=int(slot),reward=score,
                    feature=feat,image=im),actual_nfe

    def _metric_rows(self,pool,name,prompt_id,seed,cold_nfe_val,physical_new_nfe,
                     *,nbranch=0,nfresh=0,fork=None,history=None):
        entries=[]
        for slack in self.slacks:
            if slack==0.:selected=select_reward(pool,16);sel='top_ir'
            else:selected=select_diversity_with_reward_guard(pool,16,slack=slack);sel=f'diversity_slack_{slack:g}'
            stats=selection_stats(pool,selected,quality_threshold=self.quality_threshold,
                                  novelty_threshold=self.novelty_threshold)
            r=dict(prompt_id=int(prompt_id),seed=int(seed),method=name,selector=sel,slack=slack,
                   pool_size=len(pool),cold_nfe=int(cold_nfe_val),
                   cold_reward_scores=len(pool),cold_decode_images=len(pool),
                   cold_feature_images=len(pool),physical_new_nfe=int(physical_new_nfe),
                   branches=int(nbranch),fresh=int(nfresh),fork_index=fork,feature_mode=self.a.feature_mode,
                   selected_branch_count=sum(pool[i]['kind']=='branch' for i in selected),
                   selected_independent_count=sum(pool[i]['kind']=='independent' for i in selected),
                   **stats)
            entries.append(r)
        return entries

    def run_policy(self,policy:Policy,roots,folder,prompt_id,seed):
        policy.validate(self.budget)
        conf_file=folder/f'policy_{policy.name}.json'
        if conf_file.exists():
            old=json.loads(conf_file.read_text())
            if old['config']!=asdict(policy):
                raise RuntimeError('A saved policy name changed configuration. Rename it or use a new campaign.')
        before=self.a.nfe
        pool=[self._candidate('root',i,roots) for i in range(16)]
        # Extra fresh roots are immutable and cached with BoN26; their reward/feature
        # is NOT passed to the parent selector or adaptation logic.
        for rid in range(16,16+policy.fresh):pool.append(self._candidate('independent',rid,roots))
        history=[];child_features=[]
        for slot in range(policy.branches):
            parent=choose_parent(policy,roots['scores'][:16],roots['features'][:16],
                                 history,child_features,slot,prompt_id,seed)
            c,used=self._branch(parent,slot,policy.fork_index,roots,folder,seed,prompt_id)
            pool.append(c)
            history.append(dict(parent=parent,reward=float(c['reward']),slot=slot))
            child_features.append(np.asarray(c['feature']))
        cold=cold_nfe(policy)
        if cold>self.budget:raise AssertionError('COLD NFE OVER BUDGET')
        jdump(folder/f'policy_{policy.name}.json',dict(config=asdict(policy),
              cold_nfe=cold,nominal_underspend=self.budget-cold,
              actual_new_nfe=self.a.nfe-before,parent_history=history,
              root_info='Parent selector saw only base16 and this policy\'s past children'))
        save_gallery(pool,select_reward(pool,16),folder/f'gallery_{policy.name}_topir.jpg')
        if .05 in self.slacks:
            save_gallery(pool,select_diversity_with_reward_guard(pool,16,slack=.05),
                         folder/f'gallery_{policy.name}_diversity005.jpg')
        rows=self._metric_rows(pool,policy.name,prompt_id,seed,cold,self.a.nfe-before,
                               nbranch=policy.branches,nfresh=policy.fresh,
                               fork=policy.fork_index,history=history)
        return rows,pool

    def run_unit(self,prompt,prompt_id,seed,methods,*,check_replay=True):
        t0=time.perf_counter();roots,folder=self.roots(prompt,prompt_id,seed)
        expected=['bon16','bon26']+list(methods)
        def complete(method):
            return all(any(str(r['prompt_id'])==str(prompt_id) and str(r['seed'])==str(seed)
                and r['method']==method and r['selector']==sel for r in self.all_rows)
                for sel in ['top_ir']+[f'diversity_slack_{x:g}' for x in self.slacks if x>0])
        if all(complete(m) for m in expected):
            return []
        if check_replay:
            proof=folder/'replay.json'
            if proof.exists():
                pre=json.loads(proof.read_text())
                if any(float(x)>1e-5 for x in pre.values()):raise RuntimeError('Stored replay proof failed')
            else:
                jdump(proof,self.replay(roots))
        bon16=[self._candidate('root',i,roots) for i in range(16)]
        bon26=bon16+[self._candidate('independent',i,roots) for i in range(16,26)]
        save_gallery(bon26,select_reward(bon26,16),folder/'gallery_bon26_topir.jpg')
        rows=[]
        if not complete('bon16'):
            rows+=self._metric_rows(bon16,'bon16',prompt_id,seed,1600,0)
        if not complete('bon26'):
            rows+=self._metric_rows(bon26,'bon26',prompt_id,seed,2600,0,nfresh=10)
        self.all_rows+=rows;rows=[]
        csv_write(self.out/'all_rows.csv',self.all_rows)
        for name in methods:
            if complete(name):continue
            if name not in self.catalog:raise ValueError(f'Unknown method {name}')
            rr,_=self.run_policy(self.catalog[name],roots,folder,prompt_id,seed)
            rows+=rr
            self.raw_metrics+=rr
            self.all_rows+=rr
            csv_write(self.out/'all_rows.csv',self.all_rows)
        jdump(folder/'unit_summary.json',dict(prompt_id=int(prompt_id),seed=int(seed),seconds=time.perf_counter()-t0,
                                             methods=list(methods),replay=str(folder/'replay.json'),
                                             feature_mode=self.a.feature_mode,
                                             physical_nfe_total=self.a.nfe,roots_sha=digest(str(prompt)+str(seed))))
        csv_write(self.out/'all_rows.csv',self.all_rows)
        jdump(self.out/'physical_ledger.json',self.a.metadata())
        return rows


def paired_analysis(rows,methods,selector='top_ir',nboot=3000):
    r=[x for x in rows if x['selector']==selector]
    methods=[x for x in methods if x!='bon26']
    analysis=[]
    for method in methods:
        for metric in ('best_ir','mean_top16_ir','clip_distance'):
            result=paired_cluster_bootstrap(r,metric,method,base='bon26',nboot=nboot)
            analysis.append(dict(method=method,selector=selector,metric=metric,**result))
        # joint wins: same prompt/seed and same selector, with no independent-image leakage
        key={}
        for row in r:
            k=(row['prompt_id'],row['seed'])
            key.setdefault(k,{})[row['method']]=row
        joint=[]
        for methods_on_unit in key.values():
            if method not in methods_on_unit or 'bon26' not in methods_on_unit:continue
            a=methods_on_unit[method];b=methods_on_unit['bon26']
            joint.append(bool(a['mean_top16_ir']>b['mean_top16_ir'] and a['clip_distance']>b['clip_distance']))
        analysis.append(dict(method=method,selector=selector,metric='joint_wins',
                             n_units=len(joint),wins=sum(joint),win_fraction=float(np.mean(joint)) if joint else None))
    return analysis


def promotion_decision(analysis,methods,*,min_prompts=4,min_reward=.03,min_clip=.002,
                       allow_tradeoff_clip=.005):
    out=[]
    for m in methods:
        v={x['metric']:x for x in analysis if x['method']==m}
        if not all(q in v for q in ('best_ir','mean_top16_ir','clip_distance')):continue
        rr=v['mean_top16_ir'];dd=v['clip_distance'];bb=v['best_ir']
        can_assess=rr['n_prompts']>=min_prompts and dd['n_prompts']>=min_prompts
        pareto=bool(can_assess and rr['mean'] is not None and dd['mean'] is not None
            and rr['mean']>=min_reward and dd['mean']>=min_clip)
        reward_tradeoff=bool(can_assess and bb['mean'] is not None and dd['mean'] is not None
            and bb['mean']>=min_reward and dd['mean']>=-allow_tradeoff_clip)
        out.append(dict(method=m,prompts=rr['n_prompts'],pareto_development_candidate=pareto,
                        reward_tradeoff_candidate=reward_tradeoff,
                        delta_mean=rr['mean'],delta_best=bb['mean'],delta_clip=dd['mean']))
    return dict(status='ELIGIBLE_FOR_MORE_DEVELOPMENT' if any(q['pareto_development_candidate'] or q['reward_tradeoff_candidate'] for q in out)
                else ('NOT_ENOUGH_PROMPTS' if not out or max(q['prompts'] for q in out)<min_prompts else 'STOP_NO_PRACTICAL_SIGNAL'),
                thresholds=dict(min_prompts=min_prompts,min_mean_delta=min_reward,
                    min_clip_delta=min_clip,reward_tradeoff_clip_tolerance=allow_tradeoff_clip),
                candidates=out,disclaimer='Exploratory gate, NOT a significance test. Never auto-open final/TEST.')
