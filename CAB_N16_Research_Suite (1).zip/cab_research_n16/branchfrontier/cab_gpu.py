"""Optional bounded low-rank DDIM innovation controls for CAB on GPU.

Only variance_noise of the first `action_steps` suffix transitions is modified.
The text/UNet weights, timesteps, scheduled coefficients, and CFG are unchanged.
The shifted noise does NOT retain the exact base Gaussian prior conditionally on arm.
"""
from __future__ import annotations
import math
import numpy as np
import torch
from .gpu import SD15GPU


def lowfreq_action_basis(dim=4, size=64, seed=2031):
    """Deterministic orthonormal low spatial-frequency directions [dim,4,H,W].
    A unit action strength means L2=1 (NOT latent RMS=1)."""
    if dim<1 or dim>8:raise ValueError('dim must be 1..8')
    yy,xx=np.meshgrid(np.arange(size),np.arange(size),indexing='ij')
    basis=[]
    for channel in range(4):
        for axis in ('x','y'):
            raw=np.zeros((4,size,size),dtype=np.float64)
            phase=np.cos(2*np.pi*((xx if axis=='x' else yy)+.17)/size)
            raw[channel]=phase
            basis.append(raw.reshape(-1))
    A=np.stack(basis,axis=1)
    Q,_=np.linalg.qr(A)
    rng=np.random.default_rng(int(seed))
    R,_=np.linalg.qr(rng.normal(size=(8,8)))
    B=Q@R[:,:dim]
    return torch.from_numpy(B.T.copy().reshape(dim,4,size,size)).float()


class CABSD15GPU(SD15GPU):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self._cab_action=None
        self._cab_basis_cache={}

    def _basis(self,dim,seed):
        key=(int(dim),int(seed))
        if key not in self._cab_basis_cache:
            self._cab_basis_cache[key]=lowfreq_action_basis(dim=dim,seed=seed)
        return self._cab_basis_cache[key]

    def _noise(self,root_id,step_idx,noise_kind):
        eps=super()._noise(root_id,step_idx,noise_kind)
        info=self._cab_action
        if info is None or noise_kind!='fork' or root_id!=info['slot']:
            return eps
        if not info['checkpoint']<=step_idx<info['checkpoint']+info['window']:
            return eps
        if self.eta==0:
            raise RuntimeError('CAB noise action has no effect with deterministic eta=0')
        B=self._basis(info['dim'],info['seed'])
        arm=info['arm']
        direction=B[arm//2]*(1 if arm%2==0 else -1)
        # Preserves all of the standard random eps besides a fixed low-rank shift.
        # The resulting conditional innovation law is N(shift,I), not N(0,I).
        return eps + info['strength']*direction.unsqueeze(0)

    def fork_action(self,states,slots,checkpoint,*,arm,strength=2.,window=6,dim=4,basis_seed=2031):
        if len(slots)!=1 or len(states)!=1:
            raise ValueError('CAB fork_action currently processes exactly one child per call')
        if self._cab_action is not None:raise RuntimeError('Nested action context not supported')
        if arm<0 or arm>=2*dim or strength<0 or window<1 or checkpoint<0 or checkpoint>=self.steps:
            raise ValueError('Invalid CAB action parameters')
        self._cab_action=dict(slot=int(slots[0]),checkpoint=int(checkpoint),arm=int(arm),
                              strength=float(strength),window=int(window),dim=int(dim),seed=int(basis_seed))
        try:
            # Fork noise base tape is the SAME as the unmodified reward-only fork
            # at the corresponding slot, enabling a paired action perturbation.
            return self.fork(states,slots,checkpoint)
        finally:
            self._cab_action=None

    @staticmethod
    def action_kl_bound(strength,window):
        """Exact KL for a sequence of fixed Gaussian-mean-shifted innovations
        before accounting for steps whose DDIM stochastic variance is zero.
        It is a diagnostic, NOT a guarantee on final sample likelihood."""
        return .5*float(strength)**2*int(window)

    def zero_action_replay(self,state,slot=44444,checkpoint=30):
        """Cost: two true suffix passes, charged to physical (not method cold)."""
        a=self.fork(state,[slot],checkpoint)
        b=self.fork_action(state,[slot],checkpoint,arm=0,strength=0.,window=6,dim=4)
        return float((a.float()-b.float()).abs().max())
