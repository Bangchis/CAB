"""Compute lower/upper good-distinct counts with externally verified semantic labels.
UNKNOWN is neither automatically success nor failure; report BOTH bounds.
"""
from pathlib import Path
import csv,json,ast,hashlib
import numpy as np
import torch
from .report import read_rows
from .core import max_good_distinct
from .study import csv_write


def semantic_bounds(results_csv,labels_csv,out_csv,*,distance_threshold=.08):
    results=read_rows(results_csv)
    labels={}
    with Path(labels_csv).open(encoding='utf-8') as label_file:
      for row in csv.DictReader(label_file):
        key=(int(row['prompt_id']),row['image_sha'])
        tag=row['semantic_pass'].strip().upper()
        if tag not in {'SUCCESS','FAIL','UNKNOWN'}:raise ValueError('Tag must be SUCCESS/FAIL/UNKNOWN')
        if key in labels and labels[key]!=tag:raise ValueError('Conflicting labels for same image/prompt')
        labels[key]=tag
    base=Path(results_csv).parent
    record_cache={};out=[]
    for row in results:
        key=(row['prompt_id'],row['seed'])
        folders=list(base.glob(f'unit_{key[0]:03d}_{key[1]}_*'))
        if len(folders)!=1:raise ValueError('Missing/ambiguous saved prompt unit')
        unit=folders[0]
        if key not in record_cache:
            record_cache[key]=np.load(unit/'root_features.npy')
        selected=ast.literal_eval(row['selected_ids']) if isinstance(row['selected_ids'],str) else row['selected_ids']
        features=[];tags=[]
        for identifier in selected:
            if identifier.startswith('root_') or identifier.startswith('independent_'):
                idx=int(identifier.split('_',1)[1])
                imgfile=unit/f'root_{idx:02d}.png'
                feat=record_cache[key][idx]
            else:
                folder_name='action_children' if identifier.startswith('action_') else 'children'
                imgfile=unit/folder_name/f'{identifier}.png'
                if not imgfile.exists():
                    raise FileNotFoundError(f'Missing terminal selected candidate {identifier}: {imgfile}')
                sub=torch.load(imgfile.with_suffix('.pt'),map_location='cpu',weights_only=False)
                feat=np.asarray(sub['feature'])
            digest=hashlib.sha256(imgfile.read_bytes()).hexdigest()
            tags.append(labels.get((int(key[0]),digest),'UNKNOWN'))
            features.append(feat)
        features=np.stack(features)
        one=np.ones(len(tags))
        low=[i for i,s in enumerate(tags) if s=='SUCCESS']
        high=[i for i,s in enumerate(tags) if s!='FAIL']
        # re-encode label as 1/0, same graph/method features on each bound
        rlo=np.array([1 if i in low else 0 for i in range(len(tags))],float)
        rhi=np.array([1 if i in high else 0 for i in range(len(tags))],float)
        lower=max_good_distinct(rlo,features,.5,distance_threshold)
        upper=max_good_distinct(rhi,features,.5,distance_threshold)
        out.append(dict(prompt_id=key[0],seed=key[1],method=row['method'],selector=row['selector'],
                semantic_good_distinct_lower=lower,semantic_good_distinct_upper=upper,
                known_success=len(low),known_fail=sum(x=='FAIL' for x in tags),
                unknown=sum(x=='UNKNOWN' for x in tags),n_selected=len(tags),
                clip_threshold=distance_threshold))
    csv_write(out_csv,out)
    return out
