"""Offline sweep/analysis. Never changes generated images or online policy choices."""
from pathlib import Path
import csv,math,json
import numpy as np
from .study import paired_analysis,promotion_decision,csv_write,jdump


def read_rows(path):
    with open(path,newline='',encoding='utf-8') as f:a=list(csv.DictReader(f))
    if not a:raise ValueError('No results')
    for r in a:
        for k in ('prompt_id','seed','cold_nfe','branches','fresh','pool_size','selected_branch_count'):
            if k in r and r[k] not in ('',None):r[k]=int(r[k])
        for k in ('best_ir','mean_top16_ir','clip_distance','slack','worst_ir'):
            if k in r and r[k] not in ('',None):r[k]=float(r[k])
    return a


def offline_selector_sweep(rows,out,min_prompts=4,nboot=3000):
    """Evaluate all predeclared selector slacks, paired against identically selected BoN26."""
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    methods=sorted({r['method'] for r in rows}-{'bon16','bon26'})
    selectors=sorted(set(r['selector'] for r in rows))
    complete=[];decisions=[]
    for selector in selectors:
        result=paired_analysis(rows,methods,selector=selector,nboot=nboot)
        complete.extend(result)
        d=promotion_decision(result,methods,min_prompts=min_prompts)
        d['selector']=selector
        decisions.append(d)
    csv_write(out/'paired_by_selector.csv',complete)
    jdump(out/'stage_gate_by_selector.json',decisions)
    scores=[]
    for d in decisions:
        for q in d['candidates']:
            scores.append(dict(selector=d['selector'],**q))
    csv_write(out/'selector_frontier.csv',scores)
    try:
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(9,7))
        ax.axhline(0,color='.5',linewidth=1);ax.axvline(0,color='.5',linewidth=1)
        for j,q in enumerate(scores):
            if q['delta_mean'] is None or q['delta_clip'] is None:continue
            ax.scatter(q['delta_mean'],q['delta_clip'],s=24)
            ax.annotate(f"{q['method']}:{q['selector']}",(q['delta_mean'],q['delta_clip']),fontsize=7)
        ax.set_xlabel('Δ top16 mean IR versus BoN26 (same selector)')
        ax.set_ylabel('Δ CLIP cosine distance versus BoN26 (same selector)')
        ax.set_title('Development selector sweep – no new neural calls')
        fig.tight_layout();fig.savefig(out/'reward_diversity_frontier.png',dpi=165);plt.close(fig)
    except ImportError:pass
    return decisions


def method_vs_method(rows,method,baseline='reward14',selector='top_ir',nboot=3000):
    return paired_analysis(rows,[method],selector=selector,nboot=nboot) if baseline=='bon26' else _contrast(rows,method,baseline,selector,nboot)


def _contrast(rows,method,baseline,selector,nboot):
    from .core import paired_cluster_bootstrap
    rr=[r for r in rows if r['selector']==selector]
    return [dict(method=method,baseline=baseline,selector=selector,metric=metric,
                 **paired_cluster_bootstrap(rr,metric,method,base=baseline,nboot=nboot))
            for metric in ('best_ir','mean_top16_ir','clip_distance')]
