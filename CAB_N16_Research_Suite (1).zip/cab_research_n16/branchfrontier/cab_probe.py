"""Explicitly charged paired action-vs-no-action diagnostic (NOT a method result)."""
from __future__ import annotations
import numpy as np
from pathlib import Path
from .core import top_indices,normalized
from .study import jdump


def paired_action_probe(study,prompt,prompt_id,seed,*,parents=2,checkpoint=30,
                        arms=(0,1),strength=2.,window=6,dim=4,basis_seed=2031):
    root,folder=study.roots(prompt,prompt_id,seed)
    parent_ids=top_indices(root['scores'][:16],parents)
    rows=[]
    before=study.a.nfe
    for k,parent in enumerate(parent_ids):
        start=root['checkpoints'][checkpoint][parent:parent+1].clone()
        # All candidate outcomes within a parent use the exact same slot noise tape.
        slot=40000+k
        neutral=study.a.fork(start,[slot],checkpoint)
        _,ref_reward,ref_features=study.a.finish(neutral)
        rr=float(ref_reward[0]);ref_feat=np.asarray(ref_features[0],float)
        for arm in arms:
            edited=study.a.fork_action(start,[slot],checkpoint,arm=arm,
                strength=strength,window=window,dim=dim,basis_seed=basis_seed)
            _,result_reward,features=study.a.finish(edited)
            dr=float(result_reward[0]-rr)
            feat=np.asarray(features[0],float)
            dist=float(np.clip(1-normalized(feat)@normalized(ref_feat),0,2))
            state_diff=float((edited.float()-neutral.float()).square().mean().sqrt())
            rows.append(dict(prompt_id=int(prompt_id),seed=int(seed),parent=int(parent),
                arm=int(arm),root_reward=float(root['scores'][parent]),
                no_action_reward=rr,action_reward=float(result_reward[0]),
                paired_reward_delta=dr,terminal_clip_distance=dist,
                terminal_latent_rms_delta=state_diff))
    summary=dict(rows=rows,actual_physical_nfe=study.a.nfe-before,
        median_abs_reward_delta=float(np.median(np.abs([x['paired_reward_delta'] for x in rows]))),
        median_clip_delta=float(np.median([x['terminal_clip_distance'] for x in rows])),
        note='Diagnostic only; charged full suffix cost; not a free extra method output; test fresh actions/noise later.')
    jdump(folder/'CAB_ACTION_PROBE.json',summary)
    return summary
