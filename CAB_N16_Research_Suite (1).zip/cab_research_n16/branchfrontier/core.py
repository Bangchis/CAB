"""Pure numpy methods for fixed-budget branching & quality/diversity selection.
No model code in this module, so it can be unit tested on CPU.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, math
import numpy as np


def stable_seed(*items):
    raw=json.dumps(items,sort_keys=True,default=str,separators=(',',':')).encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8], 'big') % (2**63-1)


def normalized(x):
    x=np.asarray(x,dtype=np.float64)
    return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-12)


def cosine_dist(x):
    v=normalized(x)
    return np.clip(1-v@v.T,0.,2.)


def pairwise_diversity(x):
    a=np.asarray(x)
    if len(a)<2:return 0.
    d=cosine_dist(a)
    return float(d[np.triu_indices(len(d),1)].mean())


def top_indices(rewards,n):
    r=np.asarray(rewards,dtype=float)
    if not np.isfinite(r).all():raise ValueError('Non-finite reward')
    return sorted(range(len(r)), key=lambda i:(-float(r[i]),i))[:n]


def max_good_distinct(rewards,features,threshold,minimum_distance):
    """Maximum independent set for <=16 terminal outputs. Proxy ONLY, not semantic success."""
    scores=np.asarray(rewards,dtype=float)
    eligible=np.where(scores>=float(threshold))[0]
    if len(eligible)>16:raise ValueError('Only selected outputs <=16 are supported')
    if len(eligible)==0:return 0
    d=cosine_dist(np.asarray(features)[eligible]);n=len(eligible)
    neighbors=[sum(1<<j for j in range(n) if j!=i and d[i,j]<minimum_distance) for i in range(n)]
    # Branch-and-bound enumeration for <=16 nodes.
    best=0
    def visit(remaining,count):
        nonlocal best
        if not remaining:
            best=max(best,count);return
        if count+remaining.bit_count()<=best:return
        i=(remaining & -remaining).bit_length()-1
        visit(remaining & ~(1<<i) & ~neighbors[i],count+1)
        visit(remaining & ~(1<<i),count)
    visit((1<<n)-1,0)
    return best


def selection_stats(pool,selected,*,quality_threshold=None,novelty_threshold=0.08):
    r=np.array([pool[i]['reward'] for i in selected],dtype=float)
    x=np.array([pool[i]['feature'] for i in selected],dtype=float)
    out=dict(best_ir=float(r.max()),mean_top16_ir=float(r.mean()),clip_distance=pairwise_diversity(x),
             worst_ir=float(r.min()),n_selected=len(selected),selected_ids=[pool[i]['id'] for i in selected])
    if quality_threshold is not None:
        out['good_distinct_proxy']=int(max_good_distinct(r,x,quality_threshold,novelty_threshold))
        out['num_pass_ir']=int((r>=quality_threshold).sum())
    return out


def select_reward(pool,k=16):
    return top_indices([a['reward'] for a in pool],k)


def select_diversity_with_reward_guard(pool,k=16,slack=.04,max_swaps=40):
    """Increase mean pairwise cosine distance, subject to mean reward >= topK_reward - slack.
    Same fixed selector is applied to method and BoN pools. Does NOT guarantee beating BoN.
    """
    if len(pool)<k:raise ValueError('Need >=k candidates')
    if slack<0:raise ValueError('slack>=0')
    scores=np.asarray([q['reward'] for q in pool],dtype=float)
    feats=normalized([q['feature'] for q in pool]);d=cosine_dist(feats)
    base=select_reward(pool,k);reward_floor=float(scores[base].mean()-slack)
    chosen=list(base);chset=set(chosen)
    def dv(ids):
        v=d[np.ix_(ids,ids)]
        return float(v[np.triu_indices(len(ids),1)].mean())
    cur=dv(chosen)
    for _ in range(max_swaps):
        best=None
        for p,old in enumerate(chosen):
            for new in range(len(pool)):
                if new in chset:continue
                if (scores[chosen].sum()-scores[old]+scores[new])/k <reward_floor-1e-12:continue
                proposal=chosen[:];proposal[p]=new
                dd=dv(proposal)
                if dd>cur+1e-12 and (best is None or dd>best[0]+1e-12 or
                                     (abs(dd-best[0])<=1e-12 and (new,old)<(best[1],best[2]))):
                    best=(dd,new,old,p)
        if best is None:break
        cur,new,old,p=best
        chosen[p]=new;chset.remove(old);chset.add(new)
    return sorted(chosen,key=lambda i:(-scores[i],i))


def farthest_medoid_labels(features,groups=4):
    feats=normalized(features);n=len(feats)
    if n==0:return np.empty(0,dtype=int)
    centers=[0]
    while len(centers)<min(n,groups):
        dist=1-feats@feats[np.asarray(centers)].T
        candidate=int(np.argmax(dist.min(axis=1)))
        if candidate in centers:break
        centers.append(candidate)
    dist=1-feats@feats[np.asarray(centers)].T
    return np.argmin(dist,axis=1)

@dataclass(frozen=True)
class Policy:
    name:str
    kind:str="reward_only"  # uniform/reward_only/adaptive/coverage/adaptive_coverage
    fork_index:int=30
    branches:int=14
    fresh:int=0
    parent_pool:int=4
    temperature:float=.75
    ucb:float=.3
    feedback:float=.8
    negative_penalty:float=.5
    coverage:float=.5
    explore_floor:float=.15
    max_offspring:int=6

    def validate(self,limit=2600,T=100,N=16):
        if self.branches<0 or self.fresh<0 or self.parent_pool<1:raise ValueError('bad counts')
        if not 0<self.fork_index<T:raise ValueError('invalid checkpoint')
        if not(0<=self.explore_floor<=1):raise ValueError('bad explore_floor')
        if self.kind not in {'uniform','reward_only','adaptive','coverage','adaptive_coverage'}:
            raise ValueError('unknown policy: '+self.kind)
        if cold_nfe(self,T=T,N=N)>limit:raise ValueError(f'{self.name}: over budget {cold_nfe(self)} > {limit}')
        return self


def cold_nfe(policy,T=100,N=16):
    return N*T+policy.branches*(T-policy.fork_index)+policy.fresh*T


def policy_manifest():
    """Predeclared candidates; a stage plan chooses which to execute."""
    return [
        Policy('uniform14','uniform',30,14,0,4,max_offspring=4),
        Policy('reward14','reward_only',30,14,0,4,max_offspring=4),
        Policy('adaptive14','adaptive',30,14,0,4,max_offspring=4),
        Policy('coverage14','coverage',30,14,0,8,max_offspring=4,coverage=1.),
        Policy('adaptive_coverage14','adaptive_coverage',30,14,0,8,max_offspring=4),
        Policy('hybrid10b3f','adaptive_coverage',30,10,3,8,max_offspring=4),
        Policy('hybrid4b7f','adaptive_coverage',30,4,7,8,max_offspring=3),
        Policy('hybrid10_reward','reward_only',30,10,3,4,max_offspring=4),
        Policy('hybrid4_reward','reward_only',30,4,7,4,max_offspring=3),
        Policy('early12','adaptive_coverage',20,12,0,8,max_offspring=4),
        Policy('late16','adaptive_coverage',40,16,0,8,max_offspring=4),
        Policy('late16_reward','reward_only',40,16,0,4,max_offspring=4),
        Policy('hybrid_coverage10','coverage',30,10,3,8,max_offspring=4,coverage=1.),
        Policy('hybrid5b6f','adaptive_coverage',20,5,6,8,max_offspring=3), # 16*100 +5*80+600=2600
    ]


def choose_parent(policy,base_rewards,base_features,history,child_features,slot,prompt_id,run_seed):
    """Each call uses ONLY base16 and observed children (causal online decision)."""
    policy.validate()
    r=np.asarray(base_rewards,dtype=float)
    pool=top_indices(r,min(policy.parent_pool,len(r)))
    count=np.array([sum(h['parent']==i for h in history) for i in pool],dtype=int)
    eligible=np.where(count<policy.max_offspring)[0]
    if len(eligible)==0:raise ValueError('offspring cap exhausted: increase pool/cap')
    if policy.kind=='uniform':
        v=np.where(count==count.min())[0]
        v=[q for q in v if q in eligible]
        if not v:v=eligible
        # stable random tie, no terminal rewards are consulted
        rng=np.random.default_rng(stable_seed('choice',prompt_id,run_seed,slot))
        return pool[int(v[int(rng.integers(len(v)))])]
    rscale=max(float(np.quantile(r,.75)-np.quantile(r,.25)),.25)
    standardized=(r[np.asarray(pool)]-float(np.median(r)))/rscale
    utility=standardized/max(policy.temperature,.05)
    if policy.kind in ('adaptive','adaptive_coverage'):
        floor=float(np.quantile(r,.75))
        for j,parent in enumerate(pool):
            scores=[h['reward'] for h in history if h['parent']==parent]
            ok=sum(q>=floor for q in scores)
            fail=len(scores)-ok
            prob=(1.+ok)/(2.+len(scores))
            utility[j]+=policy.feedback*prob-policy.negative_penalty*fail/(2.+len(scores))
            utility[j]+=policy.ucb*math.sqrt(math.log(2.+len(history))/(1.+len(scores)))
    if policy.kind in ('coverage','adaptive_coverage'):
        labels=farthest_medoid_labels(np.asarray(base_features)[pool],4)
        for j,parent in enumerate(pool):
            group=int(labels[j]);used=sum(int(labels[pool.index(h['parent'])])==group for h in history if h['parent'] in pool)
            utility[j]-=policy.coverage*used/max(1.,policy.branches/len(set(labels)))
            # Novelty penalty for repeatedly exploiting a visually indistinguishable continuation
            childs=[child_features[ii] for ii,h in enumerate(history) if h['parent']==parent]
            if childs:
                d=1-normalized(np.array(childs))@normalized(base_features[parent]).reshape(-1,1)
                utility[j]-=0.2*sum(float(x<.04) for x in d.reshape(-1))
    utility=np.clip(utility,-40,40)
    feasible=np.zeros(len(pool),dtype=bool);feasible[eligible]=True
    utility[~feasible]=-1e10
    ex=np.exp(utility-np.max(utility[eligible]));ex[~feasible]=0.
    p=ex/ex.sum()
    # Exploration floor is spread over eligible donor pool, not over every latent in image space.
    u=np.zeros(len(pool),dtype=float);u[eligible]=1/len(eligible)
    p=(1-policy.explore_floor)*p+policy.explore_floor*u
    rng=np.random.default_rng(stable_seed('choice',prompt_id,run_seed,slot))
    return pool[int(rng.choice(len(pool),p=p))]


def stage_specs(name='pilot'):
    """Staged; expand only on development; final is never invoked automatically."""
    if name=='smoke':return ['reward14','uniform14','hybrid10b3f']
    if name=='pilot':return ['reward14','uniform14','adaptive14','coverage14',
                             'hybrid10b3f','hybrid4b7f']
    if name=='extended':return [p.name for p in policy_manifest()]
    raise ValueError(name)


def mean_paired_by_prompt(rows,metric,method,baseline='bon26'):
    """Average over replicates within each prompt; then average prompts."""
    groups={}
    for row in rows:
        key=(str(row['prompt_id']),int(row['seed']))
        groups.setdefault(key,{})[row['method']]=row
    prompts={}
    for (prompt,seed),methods in groups.items():
        if method in methods and baseline in methods:
            prompts.setdefault(prompt,[]).append(float(methods[method][metric])-float(methods[baseline][metric]))
    return {p:float(np.mean(v)) for p,v in prompts.items()}


def paired_cluster_bootstrap(rows,metric,method,base='bon26',nboot=3000,seed=17):
    vals=list(mean_paired_by_prompt(rows,metric,method,base).values())
    if not vals:return dict(n_prompts=0,mean=None,ci95=[None,None])
    a=np.asarray(vals,float)
    rng=np.random.default_rng(seed)
    draws=np.mean(rng.choice(a,size=(nboot,len(a)),replace=True),axis=1)
    return dict(n_prompts=len(a),mean=float(a.mean()),ci95=np.quantile(draws,[.025,.975]).tolist(),wins=int((a>0).sum()),
                losses=int((a<0).sum()))
