"""CAB experiments sharing the verified branchfrontier SD15 reference runner.

Uses the existing Study cache, exact replay, paired seeds, ImageReward, CLIP
and cold NFE accounting. Never accesses future child rewards in selection.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import hashlib,json,math
import numpy as np
import torch
from PIL import Image
from .cab import CABPolicy, default_policies, select_arm, feedback_labels
from .core import Policy,choose_parent,normalized,select_reward,select_diversity_with_reward_guard
from .study import Study,jdump,png_sha,save_gallery


def _sha_json(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]


def novelty_to_archive(feature,archive_features):
    if not archive_features:return 2.
    f=normalized(np.asarray(feature,dtype=float))
    a=normalized(np.asarray(archive_features,dtype=float))
    return float(np.clip(np.min(1-a@f),0.,2.))


class CABStudy(Study):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.catalog.update({p.name:p for p in default_policies()})

    def _branch_action(self,policy:CABPolicy,arm,parent,slot,roots,folder,seed,prompt_id):
        params=dict(parent=int(parent),slot=int(slot),checkpoint=int(policy.fork_index),
                    arm=int(arm),strength=round(float(policy.action_strength),8),
                    window=int(policy.action_steps),dim=int(policy.action_dim),
                    basis_seed=int(policy.action_basis_seed))
        # Reuse exact same computed child only for EXACT matching action/input.
        # Do not key by policy name, because that would throw away honest cache sharing.
        d=folder/'action_children';d.mkdir(parents=True,exist_ok=True)
        stem='action_'+_sha_json(params)
        pt=d/f'{stem}.pt';png=d/f'{stem}.png'
        if pt.exists() and png.exists():
            record=torch.load(pt,map_location='cpu',weights_only=False)
            if record['params']!=params or record['prompt_id']!=int(prompt_id) or record['seed']!=int(seed):
                raise RuntimeError('Action cache mismatched to frozen recipe')
            im=Image.open(png).convert('RGB')
            if record['image_sha']!=png_sha(im):raise RuntimeError('Cached child pixels changed')
            score=float(record['reward']);feature=np.asarray(record['feature'],dtype=np.float32)
            used=0
        else:
            if not hasattr(self.a,'fork_action'):
                raise RuntimeError('CAB policy requires fork_action in the adapter')
            start=roots['checkpoints'][policy.fork_index][parent:parent+1].clone()
            before=self.a.nfe
            terminal=self.a.fork_action(start,[10_000+slot],policy.fork_index,
                  arm=arm,strength=policy.action_strength,window=policy.action_steps,
                  dim=policy.action_dim,basis_seed=policy.action_basis_seed)
            used=self.a.nfe-before
            expected=100-policy.fork_index
            if used!=expected:raise AssertionError(f'CAB NFE mismatch {used}!={expected}')
            ims,scores,feats=self.a.finish(terminal)
            im=ims[0];score=float(scores[0]);feature=np.asarray(feats[0],dtype='float32')
            if not np.isfinite(score) or not np.isfinite(feature).all():raise ValueError('Nonfinite CAB output')
            im.save(png)
            torch.save(dict(params=params,prompt_id=int(prompt_id),seed=int(seed),
                reward=score,feature=feature,terminal=terminal[0].detach().cpu(),
                image_sha=png_sha(im)),pt)
        child=dict(id=stem,kind='branch',parent=int(parent),slot=int(slot),arm=int(arm),
                   checkpoint=int(policy.fork_index),reward=score,
                   feature=feature,image=im)
        return child,used

    def run_policy(self,policy,roots,folder,prompt_id,seed):
        if not isinstance(policy,CABPolicy):
            return super().run_policy(policy,roots,folder,prompt_id,seed)
        policy.validate(self.budget)
        conf=folder/f'policy_{policy.name}.json'
        if conf.exists():
            saved=json.loads(conf.read_text())
            if saved['config']!=asdict(policy):
                raise RuntimeError('A policy was changed under the same name; choose a new run/config ID')
        before=self.a.nfe
        base_scores=np.asarray(roots['scores'][:16],float)
        base_feats=np.asarray(roots['features'][:16],float)
        pool=[self._candidate('root',i,roots) for i in range(16)]
        # These fresh rewards are used in FINAL POOL ONLY, never for parent/action decisions.
        for rid in range(16,16+policy.fresh):
            pool.append(self._candidate('independent',rid,roots))
        selector_parent=Policy(name='cab_reward_only_parent',kind='reward_only',
            fork_index=policy.fork_index,branches=policy.branches,fresh=policy.fresh,
            parent_pool=policy.parent_pool,temperature=policy.parent_temperature,
            explore_floor=policy.parent_explore_floor,max_offspring=policy.max_offspring)
        history=[];child_features=[];traces=[]
        for slot in range(policy.branches):
            # Reward-only parent chooser: same parent order as equal-parameter reward-only
            # control, because it does not use children rewards, only historical counts.
            parent=choose_parent(selector_parent,base_scores,base_feats,history,child_features,
                slot,prompt_id,seed)
            arm,decision=select_arm(policy,parent,base_feats,history,
                prompt_id,seed,slot)
            # Stronger causal label: compare against the NO-ACTION continuation of
            # this exact parent, slot and future-noise tape. This consumes another
            # (100-fork_index) NFE per decision, included in paired policy cold cost.
            # The neutral rollout is also a legitimate final candidate.
            neutral=None;neutral_used=0
            if policy.paired_neutral:
                neutral,neutral_used=self._branch(parent,slot,policy.fork_index,roots,folder,seed,prompt_id)
                pool.append(neutral)
            child,used=self._branch_action(policy,arm,parent,slot,roots,folder,seed,prompt_id)
            # Archive BEFORE adding this acted child, so novelty sees only past
            # outputs and (for paired policies) its legitimately observed neutral.
            # Baseline roots are legitimate preexisting completed images.
            # Do not let the action learner inspect reserved fresh roots (root IDs >=16).
            # Those are final-pool candidates only, not past action feedback.
            goodarchive=[q['feature'] for q in pool if q['kind']!='independent'
                         and q['reward']>=float(np.quantile(base_scores,.75))]
            novel=novelty_to_archive(child['feature'],goodarchive)
            feedback_reference=float(neutral['reward']) if neutral is not None else float(base_scores[parent])
            lab=feedback_labels(child['reward'],feedback_reference,novel,policy)
            history.append(dict(parent=int(parent),slot=int(slot),arm=int(arm),
                                reward=float(child['reward']),labels=lab,novelty=novel))
            child_features.append(child['feature']);pool.append(child)
            traces.append(dict(slot=int(slot),parent=int(parent),arm=int(arm),reward=float(child['reward']),
                parent_root_reward=float(base_scores[parent]),
                neutral_reward=(float(neutral['reward']) if neutral is not None else None),
                feedback_reference_reward=feedback_reference,feedback_reference_type=(
                    'paired_same_tape_neutral' if policy.paired_neutral else 'original_root_different_suffix'),
                novelty=float(novel),labels=lab,
                selection=decision,new_physical_nfe=int(used)))
        cold=policy.cold_nfe()
        if cold>self.budget:raise AssertionError('CAB COLD NFE OVER BUDGET')
        if getattr(self.a,'feature_mode',None)!='CLIP' and getattr(self.a,'model_id',None)!='synthetic-test':
            raise RuntimeError('CAB science must use CLIP features; pixel mode is for debug only')
        info=dict(config=asdict(policy),cold_nfe=int(cold),
            nominal_underspend=int(self.budget-cold),actual_new_nfe=int(self.a.nfe-before),
            parent_history=history,traces=traces,
            note='Same reward-only parent schedule across corresponding CAB policies. Paired mode uses an explicitly charged same-tape neutral child.',
            paired_neutral=policy.paired_neutral,number_of_decision_slots=policy.branches,
            nonuniform_rate=float(np.mean([a['selection']['activated'] for a in traces])) if traces else 0.,
            mean_tv_from_uniform=float(np.mean([a['selection']['tv_from_uniform'] for a in traces])) if traces else 0.,
            action_shift_noise_kl_nominal=.5*policy.action_strength**2*min(policy.action_steps,100-policy.fork_index))
        jdump(conf,info)
        save_gallery(pool,select_reward(pool,16),folder/f'gallery_{policy.name}_topir.jpg')
        rows=self._metric_rows(pool,policy.name,prompt_id,seed,cold,self.a.nfe-before,
                nbranch=policy.branches*(2 if policy.paired_neutral else 1),
                nfresh=policy.fresh,fork=policy.fork_index,history=history)
        for row in rows:
            row.update(cab_mode=policy.mode,cab_action_strength=policy.action_strength,
                       cab_feedback_type=('paired' if policy.paired_neutral else 'root_relative'),
                       cab_decision_slots=policy.branches,
                       cab_action_active_rate=info['nonuniform_rate'],
                       cab_action_avg_tv=info['mean_tv_from_uniform'],
                       cab_negative_observations=sum(h['labels']['negative']>0 for h in history),
                       cab_positive_observations=sum(h['labels']['positive']>0 for h in history),
                       cab_duplicate_observations=sum(h['labels']['redundant']>0 for h in history),
                       cab_noise_path_kl_nominal=info['action_shift_noise_kl_nominal'])
        return rows,pool
