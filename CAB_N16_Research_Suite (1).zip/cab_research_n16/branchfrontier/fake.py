"""Fast CPU synthetic adapter for validating mechanics. NOT SD results."""
import math
import numpy as np
import torch
from PIL import Image
from .core import stable_seed,normalized

class FakeAdapter:
    revision='fake-v1';model_id='synthetic-test';feature_mode='PIXEL_DEBUG'
    class Encoder:
        model_id='fake_features'
        calls=0;seconds=0
    def __init__(self):
        self.feature_encoder=self.Encoder();self.steps=100;self.nfe=0;self.cfg_branch_nfe=0
        self.forward_calls=0;self.reward_calls=0;self.decode_calls=0
        self.prompt_id=None;self.root_seed=None
    def bind(self,prompt,prompt_id,root_seed=None):
        self.prompt=str(prompt);self.prompt_id=int(prompt_id);self.root_seed=int(root_seed)
    def full_roots(self,ids,capture=()):
        xs=torch.tensor([[[[float(i),float(i%4)],[0.,0.]]] for i in ids],dtype=torch.float32)
        self.nfe+=100*len(ids);self.cfg_branch_nfe+=200*len(ids)
        return xs,{int(k):xs.clone() for k in capture}
    def fork(self,states,slots,checkpoint):
        a=states.clone()
        for j,slot in enumerate(slots):
            rng=np.random.default_rng(stable_seed(self.prompt_id,self.root_seed,'fork',slot,checkpoint))
            a[j,0,1,0]=float(rng.normal(.7,.3))
            a[j,0,1,1]=float(rng.normal(.5,.3))
        n=(100-int(checkpoint))*len(slots)
        self.nfe+=n;self.cfg_branch_nfe+=2*n
        return a
    def finish(self,final):
        ims=[];r=[];fs=[]
        for x in final:
            i=float(x[0,0,0]);j=float(x[0,0,1]);noise=float(x[0,1,0]);delta=float(x[0,1,1])
            reward=-(i%5-2)**2*.1+ .5*noise-.15*abs(delta)+.02*j
            r.append(reward)
            u=np.array([np.cos(i*.8+delta),np.sin(i*.8+delta),1.+.1*noise],float)
            fs.append(normalized(u).astype('float32'))
            arr=np.full((32,32,3),int((i*8)%200+20),dtype='uint8')
            arr[:,:,1]=int((delta*40)%180+30)
            ims.append(Image.fromarray(arr,'RGB'))
        self.reward_calls+=len(final);self.decode_calls+=len(final)
        self.feature_encoder.calls+=len(final)
        return ims,np.asarray(r,float),np.array(fs)
    def replay_check(self,roots,cp=30,ids=(0,1,2,3)):
        assert torch.equal(roots['final'][list(ids)],roots['checkpoints'][cp][list(ids)])
        return 0.
    def metadata(self):
        return dict(backend='fake_CPU_NOT_NEURAL',physical_nfe=self.nfe,cfg_branches=self.cfg_branch_nfe,
                    reward_calls=self.reward_calls,clip_evaluations=0,feature_mode=self.feature_mode)
