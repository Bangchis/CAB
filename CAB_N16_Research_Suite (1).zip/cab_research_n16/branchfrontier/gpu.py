"""CUDA Diffusers DDIM100 adapter, matching uploaded standalone GPU BoN settings.
All method-vs-BoN comparisons use THIS manual loop and keyed CRN tapes.
Not claimed bitwise identical to the uploaded pipe(..., generator=...) baseline.
"""
from __future__ import annotations
from pathlib import Path
import time, json, hashlib
import numpy as np
import torch
from .core import stable_seed,normalized

class CLIPImageEncoder:
    def __init__(self,model_id='openai/clip-vit-base-patch32',device='cpu',local_files_only=False):
        from transformers import CLIPModel,CLIPProcessor
        self.model=CLIPModel.from_pretrained(model_id,local_files_only=local_files_only).to(device).eval()
        self.processor=CLIPProcessor.from_pretrained(model_id,local_files_only=local_files_only)
        self.device=device;self.model_id=model_id;self.cached={};self.calls=0;self.seconds=0.
    def encode(self,images):
        result=[]
        for im in images:
            key=hashlib.sha256(im.tobytes()).hexdigest()
            if key not in self.cached:
                st=time.perf_counter();inp=self.processor(images=im,return_tensors='pt')
                inp={k:v.to(self.device) for k,v in inp.items()}
                with torch.inference_mode():
                    feat=self.model.get_image_features(**inp)
                if not torch.is_tensor(feat):
                    feat=feat.pooler_output if hasattr(feat,'pooler_output') else feat[0]
                a=feat.detach().float().cpu().numpy().reshape(-1)
                self.cached[key]=normalized(a).astype('float32')
                self.seconds+=time.perf_counter()-st;self.calls+=1
            result.append(self.cached[key])
        return np.stack(result,axis=0)

class PixelFeatureEncoder:
    """Debug-only proxy. Never label these features as CLIP diversity."""
    model_id='pixel_16x16_debug_NOT_CLIP'
    def __init__(self):self.calls=0;self.seconds=0.
    def encode(self,images):
        x=[]
        for im in images:
            a=np.asarray(im.convert('RGB').resize((16,16)),dtype='float32')/255.
            x.append(normalized(a.reshape(-1)).astype('float32'));self.calls+=1
        return np.stack(x)

class SD15GPU:
    def __init__(self,*,model_id='stable-diffusion-v1-5/stable-diffusion-v1-5',
                 revision='451f4fe16113bff5a5d2269ed5ad43b0592e9a14',
                 reward_device='cpu',cfg=7.5,eta=1.,steps=100,batch_size=1,
                 dtype=None,root_seed=2026102101,enable_clip=True,clip_device='cpu',
                 local_files_only=False):
        from diffusers import StableDiffusionPipeline,DDIMScheduler
        import ImageReward as RM
        if not torch.cuda.is_available():raise RuntimeError('CUDA required. Use fake tests first.')
        self.device='cuda';self.dtype=(dtype if dtype is not None else
           (torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16))
        self.root_seed=int(root_seed);self.prompt_id=None;self.prompt=None
        self.steps=int(steps);self.cfg=float(cfg);self.eta=float(eta);self.batch_size=int(batch_size)
        if self.steps!=100:raise ValueError('This study locks T=100. Other schedules need a new manifest.')
        t0=time.perf_counter()
        self.pipe=StableDiffusionPipeline.from_pretrained(
            model_id,revision=revision,torch_dtype=self.dtype,use_safetensors=True,
            safety_checker=None,feature_extractor=None,requires_safety_checker=False,
            local_files_only=local_files_only).to(self.device)
        self.pipe.scheduler=DDIMScheduler.from_config(self.pipe.scheduler.config)
        self.pipe.scheduler.set_timesteps(self.steps,device=self.device)
        self.pipe.set_progress_bar_config(disable=True)
        self.timesteps=self.pipe.scheduler.timesteps
        for m in (self.pipe.unet,self.pipe.vae,self.pipe.text_encoder):m.eval().requires_grad_(False)
        self.model_load_s=time.perf_counter()-t0
        self.reward_model=RM.load('ImageReward-v1.0',device=reward_device)
        self.reward_model.eval()
        self.feature_encoder=CLIPImageEncoder(device=clip_device,local_files_only=local_files_only) if enable_clip else PixelFeatureEncoder()
        self.feature_mode='CLIP' if enable_clip else 'PIXEL_DEBUG'
        self.model_id=model_id;self.revision=revision
        self.nfe=0;self.cfg_branch_nfe=0;self.forward_calls=0;self.reward_calls=0;self.decode_calls=0
        self.wall_unet=0.;self.wall_decode=0.;self.wall_reward=0.
        self.positive=None;self.negative=None

    def bind(self,prompt,prompt_id,root_seed=None):
        self.prompt=str(prompt);self.prompt_id=int(prompt_id)
        if root_seed is not None:self.root_seed=int(root_seed)
        with torch.inference_mode():
            p,n,*_=self.pipe.encode_prompt(prompt=self.prompt,device=self.device,
                num_images_per_prompt=1,do_classifier_free_guidance=True,negative_prompt='')
        self.positive=p;self.negative=n

    def _noise(self,root_id,step_idx,noise_kind):
        g=torch.Generator(device='cpu').manual_seed(stable_seed(self.root_seed,self.prompt_id,noise_kind,int(root_id),int(step_idx)))
        return torch.randn((1,4,64,64),generator=g,dtype=torch.float32)

    def initial(self,root_ids):
        return torch.cat([self._noise(x,-1,'initial') for x in root_ids]).to(self.dtype)

    @torch.inference_mode()
    def advance(self,states,ids,*,start,end=None,noise_kind='root',capture=()):
        end=self.steps if end is None else int(end)
        if not (0<=start<end<=self.steps):raise ValueError('Invalid start/end')
        ids=list(map(int,ids));states=states.detach().cpu()
        if len(ids)!=len(states):raise ValueError('state/id mismatch')
        if self.positive is None:raise RuntimeError('bind prompt first')
        cap={int(k):[] for k in capture}
        finals=[]
        for lo in range(0,len(ids),self.batch_size):
            sub=ids[lo:lo+self.batch_size]
            x=states[lo:lo+len(sub)].to(self.device,dtype=self.dtype).clone()
            emb=torch.cat([self.negative.expand(len(sub),-1,-1),
                           self.positive.expand(len(sub),-1,-1)],dim=0)
            for i in range(int(start),end):
                if i in cap:cap[i].append(x.detach().cpu().clone())
                timestep=self.timesteps[i]
                inputs=self.pipe.scheduler.scale_model_input(torch.cat([x,x]),timestep)
                beg=time.perf_counter()
                y=self.pipe.unet(inputs,timestep,encoder_hidden_states=emb,return_dict=False)[0]
                if self.device=='cuda':torch.cuda.synchronize()
                self.wall_unet+=time.perf_counter()-beg
                self.forward_calls+=1;self.nfe+=len(sub);self.cfg_branch_nfe+=2*len(sub)
                unc,con=y.chunk(2)
                pred=unc.float()+self.cfg*(con.float()-unc.float())
                eps=torch.cat([self._noise(root_id,i,noise_kind) for root_id in sub]).to(self.device)
                # Explicit FP32 DDIM transition, then cast to model dtype as in frozen pilot.
                x=self.pipe.scheduler.step(pred,timestep,x.float(),eta=self.eta,
                       variance_noise=eps,return_dict=True).prev_sample.to(self.dtype)
            if end in cap:cap[end].append(x.detach().cpu().clone())
            finals.append(x.detach().cpu())
        return torch.cat(finals,dim=0),{idx:torch.cat(v,dim=0) for idx,v in cap.items() if v}

    def full_roots(self,ids,capture=(20,30,40)):
        initial=self.initial(ids)
        return self.advance(initial,ids,start=0,end=self.steps,noise_kind='root',capture=capture)

    def fork(self,states,slots,checkpoint):
        return self.advance(states,slots,start=int(checkpoint),end=self.steps,noise_kind='fork',capture=())[0]

    @torch.inference_mode()
    def finish(self,latents):
        images=[];t0=time.perf_counter()
        for k in range(0,len(latents),self.batch_size):
            x=latents[k:k+self.batch_size].to(self.device,self.dtype)
            dec=self.pipe.vae.decode(x/self.pipe.vae.config.scaling_factor,return_dict=False)[0]
            images.extend(self.pipe.image_processor.postprocess(dec,output_type='pil'))
        self.decode_calls+=len(images);self.wall_decode+=time.perf_counter()-t0
        t0=time.perf_counter()
        with torch.inference_mode():
            scores=[float(np.asarray(self.reward_model.score(self.prompt,im)).reshape(-1)[0]) for im in images]
        self.reward_calls+=len(images);self.wall_reward+=time.perf_counter()-t0
        feats=self.feature_encoder.encode(images)
        return images,np.asarray(scores,dtype=np.float64),feats

    def replay_check(self,roots,cp=30,ids=(0,1,2,3)):
        ref=roots['final'][list(ids)]
        state=roots['checkpoints'][cp][list(ids)]
        replay,_=self.advance(state,list(ids),start=cp,end=self.steps,noise_kind='root')
        error=float((replay.float()-ref.float()).abs().max())
        if error>1e-5:raise RuntimeError(f'Exact DDIM replay failed: {error}')
        return error

    def metadata(self):
        return dict(backend='sd15_gpu_manual_ddim_crn',dtype=str(self.dtype),steps=self.steps,
            cfg=self.cfg,eta=self.eta,model_id=self.model_id,model_revision=self.revision,
            clip_model=self.feature_encoder.model_id,feature_mode=self.feature_mode,
            physical_nfe=self.nfe,cfg_branches=self.cfg_branch_nfe,
            unet_calls=self.forward_calls,reward_scores=self.reward_calls,
            clip_feature_evaluations=self.feature_encoder.calls,decode_images=self.decode_calls,
            wall_unet=self.wall_unet,wall_decode=self.wall_decode,wall_reward=self.wall_reward,
            wall_clip=self.feature_encoder.seconds)
