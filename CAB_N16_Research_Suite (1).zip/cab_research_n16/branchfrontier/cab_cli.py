"""CLI for train-only CAB vs reward-only / adaptive / BoN26.

Usage: python -m branchfrontier.cab_cli plan|run|analyze ...
GPU heavy calls are explicit: no automatic TEST, no auto-tune, no auto-launch.
"""
from __future__ import annotations
import argparse,csv,json,dataclasses,hashlib,sys,re,importlib.metadata
from pathlib import Path
import numpy as np
from .cab import CABPolicy,default_policies
from .cab_study import CABStudy
from .core import policy_manifest,paired_cluster_bootstrap
from .study import jdump,csv_write


def load_prompts(path):
    items=json.loads(Path(path).read_text(encoding='utf-8'))
    if not items or not isinstance(items,list):raise ValueError('Expected non-empty TRAIN prompt JSON list')
    for p in items:
        if p.get('split')!='TRAIN' or not p.get('prompt') or not isinstance(p.get('prompt_id'),int):
            raise ValueError('Only TRAIN with explicit integer prompt_id and non-empty prompt text')
    if len({p['prompt_id'] for p in items})!=len(items):raise ValueError('Duplicate prompt IDs')
    return items


def catalog():
    return {p.name:p for p in policy_manifest()+default_policies()}


def stages():
    return {
        'smoke':['reward14','cab_uniform14','cab_contrastive14'],
        'pilot':['uniform14','reward14','adaptive14','cab_uniform14',
                 'cab_positive14','cab_negative14','cab_contrastive14','cab_shuffle_negative14'],
        'paired':['reward14','cab_pair_uniform7','cab_pair_positive7',
                  'cab_pair_negative7','cab_pair_contrastive7','cab_pair_shuffle7'],
        'hybrid':['hybrid10_reward','cab_uniform10b3f','cab_positive10b3f',
                  'cab_shuffle10b3f','cab_contrastive10b3f'],
        'timing':['cab_uniform_cp20','cab_positive_cp20','cab_shuffle_cp20',
                  'cab_contrastive_cp20','cab_uniform_cp40','cab_positive_cp40',
                  'cab_shuffle_cp40','cab_contrastive_cp40'],
        'sweep':[],
    }


def generated_grid():
    """Predeclare, then freeze one small subset; NEVER auto-run all configs."""
    candidates=[]
    for f in (30,20,40):
        n={20:12,30:14,40:16}[f]
        for strength in (1.,2.,4.):
            for mode in ('uniform_action','positive_action','shuffled_negative'):
                short={'uniform_action':'uniform','positive_action':'positive',
                       'shuffled_negative':'shuffle'}[mode]
                name=f'cab_{short}_cp{f}_s{strength:g}'.replace('.','p')
                obj=CABPolicy(name=name,mode=mode,fork_index=f,branches=n,action_strength=strength)
                obj.validate();candidates.append(obj)
            for negative in (.5,1.,2.):
                name=f'cab_cp{f}_s{strength:g}_neg{negative:g}'.replace('.','p')
                obj=CABPolicy(name=name,fork_index=f,branches=n,
                              action_strength=strength,negative_strength=negative)
                obj.validate();candidates.append(obj)
    return candidates


def full_catalog():
    out=catalog();out.update({p.name:p for p in generated_grid()});return out


def get_methods(args):
    out=args.methods.split(',') if args.methods else stages()[args.stage]
    table=full_catalog()
    if not out or len(set(out))!=len(out):raise ValueError('Duplicate or empty method names')
    for name in out:
        if name not in table:raise ValueError(f'Unknown method {name}')
        table[name].validate()
    return out,table


def freeze_manifest(path,params):
    p=Path(path)
    if p.exists():
        old=json.loads(p.read_text())
        if old!=params:raise RuntimeError('Experiment frozen configuration mismatch. Use a different --out.')
    else:jdump(p,params)


def paired(rows,method,base,metric,bootstrap=3000):
    return paired_cluster_bootstrap(rows,metric,method,base=base,nboot=bootstrap)


def _parse_rows(rows):
    out=[]
    for row in rows:
        r=dict(row)
        for f in ('best_ir','mean_top16_ir','clip_distance'):
            r[f]=float(r[f])
        out.append(r)
    return out


def analyze_rows(rows,out,*,bootstrap=3000,minimum_prompts=4):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    # CRITICAL: paired analysis must compare the SAME fixed selector.
    # Without this filter, repeated selector rows overwrite one another in
    # paired_cluster_bootstrap and masquerade as top-IR evidence.
    rows=[r for r in _parse_rows(rows) if r['selector']=='top_ir']
    methods={r['method'] for r in rows}
    targets=sorted(m for m in methods if m.startswith('cab_'))
    comps=[]
    def matched_controls(m):
        hit=re.fullmatch(r'cab_cp(20|30|40)_s([0-9p]+)_neg([0-9p]+)',m)
        if hit:
            f,strength,_=hit.groups()
            return (f'cab_uniform_cp{f}_s{strength}',f'cab_positive_cp{f}_s{strength}',
                    f'cab_shuffle_cp{f}_s{strength}')
        if m=='cab_pair_contrastive7':
            return ('cab_pair_uniform7','cab_pair_positive7','cab_pair_shuffle7')
        if m=='cab_contrastive10b3f':
            return ('cab_uniform10b3f','cab_positive10b3f','cab_shuffle10b3f')
        if m in ('cab_contrastive_cp20','cab_contrastive_cp40'):
            cp=m.rsplit('cp',1)[-1]
            return (f'cab_uniform_cp{cp}',f'cab_positive_cp{cp}',f'cab_shuffle_cp{cp}')
        hit2=re.fullmatch(r'cab_(?:uniform|positive|shuffle)_cp(20|30|40)_s([0-9p]+)',m)
        if hit2:
            f,strength=hit2.groups()
            return (f'cab_uniform_cp{f}_s{strength}',f'cab_positive_cp{f}_s{strength}',
                    f'cab_shuffle_cp{f}_s{strength}')
        return ('cab_uniform14','cab_positive14','cab_shuffle_negative14')
    for m in targets:
        uniform,positive,shuffle=matched_controls(m)
        for baseline in ('bon26','reward14','adaptive14',uniform,positive,shuffle):
            if baseline==m or baseline not in methods:continue
            for metric in ('best_ir','mean_top16_ir','clip_distance'):
                a=paired(rows,m,baseline,metric,bootstrap)
                comps.append(dict(method=m,baseline=baseline,metric=metric,**a))
    csv_write(out/'paired_controls.csv',comps)
    by={(x['method'],x['baseline'],x['metric']):x for x in comps}
    cases=[]
    for m in targets:
        reward=by.get((m,'reward14','mean_top16_ir'))
        bon=by.get((m,'bon26','best_ir'))
        div=by.get((m,'bon26','clip_distance'))
        _,positive_name,shuffle_name=matched_controls(m)
        negative=by.get((m,positive_name,'mean_top16_ir'))
        shuf=by.get((m,shuffle_name,'mean_top16_ir'))
        negative_div=by.get((m,positive_name,'clip_distance'))
        shuf_div=by.get((m,shuffle_name,'clip_distance'))
        seen=[r for r in rows if r['selector']=='top_ir' and r['method']==m]
        active=float(np.mean([float(r.get('cab_action_active_rate') or 0.) for r in seen])) if seen else 0.
        action_tv=float(np.mean([float(r.get('cab_action_avg_tv') or 0.) for r in seen])) if seen else 0.
        neg_obs=float(np.mean([float(r.get('cab_negative_observations') or 0.) for r in seen])) if seen else 0.
        adequate=bool(reward and reward['n_prompts']>=minimum_prompts)
        # Gating is intentionally more stringent than simply beating BoN once.
        useful=bool(adequate and reward['mean'] is not None and reward['mean']>=.03 and
                    bon and bon['mean'] is not None and bon['mean']>=.03)
        is_contrastive=bool(m.startswith('cab_contrastive') or
                             m=='cab_pair_contrastive7' or re.match(r'cab_cp\d+_s',m))
        reward_negative_bonus=bool(negative and shuf and negative['mean'] is not None and
            shuf['mean'] is not None and negative['mean']>=.015 and shuf['mean']>=.015)
        diversity_negative_bonus=bool(negative and shuf and negative_div and shuf_div and
            negative['mean'] is not None and shuf['mean'] is not None and
            negative_div['mean'] is not None and shuf_div['mean'] is not None and
            min(negative['mean'],shuf['mean'])>=-.01 and
            min(negative_div['mean'],shuf_div['mean'])>=.002)
        negative_distinct=bool(adequate and is_contrastive and
            (reward_negative_bonus or diversity_negative_bonus) and
            active>=.15 and action_tv>=.02 and neg_obs>0)
        pareto=bool(useful and div and div['mean'] is not None and div['mean']>=.002)
        cases.append(dict(method=m,n_prompts=reward['n_prompts'] if reward else 0,
                          mean_delta_vs_reward_only=reward['mean'] if reward else None,
                          best_delta_vs_bon26=bon['mean'] if bon else None,
                          diversity_delta_vs_bon26=div['mean'] if div else None,
                          delta_vs_positive_only=negative['mean'] if negative else None,
                          delta_vs_shuffled_negative=shuf['mean'] if shuf else None,
                          delta_div_vs_positive_only=(negative_div['mean'] if negative_div else None),
                          delta_div_vs_shuffled_negative=(shuf_div['mean'] if shuf_div else None),
                          reward_negative_bonus=reward_negative_bonus,
                          diversity_negative_bonus=diversity_negative_bonus,
                          active_frac=active,mean_action_tv=action_tv,neg_observations_per_unit=neg_obs,
                          meaningful_reward_signal=useful,negative_feedback_specific=negative_distinct,
                          pareto_candidate=pareto))
    gate='INCOMPLETE_TRAIN' if not cases or max(q['n_prompts'] for q in cases)<minimum_prompts else (
         'CAB_NEGATIVE_SIGNAL_DEVELOPMENT_ONLY' if any(q['negative_feedback_specific'] and q['pareto_candidate'] for q in cases)
         else 'HOLD_NO_CAB_SPECIFIC_PARETO_SIGNAL')
    decision=dict(status=gate,candidates=cases,
       warning='Exploratory only, not a statistical claim. No TEST run is launched.',
       criteria='CAB vs reward-only and BoN: mean IR>=0.03, best>=0.03, CLIP>=0.002. Negative-specific: reward advantage >=.015 OR diversity advantage>=.002 with IR disadvantage<=.01, against both positive-only and shuffled. Activated>=.15, TV>=.02. Development only.',
       note='Large sweeps must be preregistered in a NEW development campaign; no auto-selection.')
    jdump(out/'CAB_DECISION.json',decision)
    return decision


def plan(args):
    prompts=load_prompts(args.prompts)
    methods,table=get_methods(args)
    seeds=[int(x) for x in args.seeds.split(',')]
    plan=dict(stage=args.stage,prompts=prompts,seeds=seeds,methods=methods,
       selector_slacks=[float(x) for x in args.slacks.split(',')],
       cold={m:table[m].cold_nfe() if isinstance(table[m],CABPolicy) else
                  1600+table[m].branches*(100-table[m].fork_index)+100*table[m].fresh for m in methods},
       configs={m:dataclasses.asdict(table[m]) for m in methods},
       note='PLAN ONLY: 26 independent roots for BoN26. CAB sees first 16 and its own previous children. CAB-Paired uses 7 action/no-action pairs with 14 suffix completions charged.')
    if args.out:jdump(Path(args.out)/'PLAN.json',plan)
    print(json.dumps({k:v for k,v in plan.items() if k not in ('prompts','configs')},indent=2))
    return plan


def run(args):
    prompts=load_prompts(args.prompts)
    methods,table=get_methods(args)
    if args.stage not in ('smoke','pilot') and not args.approve_expensive:
        raise RuntimeError('hybrid/timing/extended require --approve-expensive after pilot gate')
    if args.stage=='pilot' and not args.approve_pilot:
        raise RuntimeError('pilot requires explicit --approve-pilot and sufficient TRAIN data')
    seeds=[int(s) for s in args.seeds.split(',')]
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    source_files=['core.py','gpu.py','study.py','cab.py','cab_gpu.py','cab_study.py','cab_cli.py']
    src_dir=Path(__file__).resolve().parent
    hashes={f:hashlib.sha256((src_dir/f).read_bytes()).hexdigest() for f in source_files}
    versions={q:importlib.metadata.version(q) for q in ('torch','diffusers','transformers','image-reward') }
    frozen=dict(prompts=prompts,seeds=seeds,methods=methods,source_hashes=hashes,versions=versions,
       selected_policies={m:dataclasses.asdict(table[m]) for m in methods},
       model_id=args.model_id,model_revision=args.model_revision,
       fixed=dict(cfg=7.5,eta=1.0,T=100,outputs=16,cold_budget=2600),
       slacks=[float(x) for x in args.slacks.split(',')],
       stage=args.stage,feature_mode='CLIP',reward_name='ImageReward-v1.0')
    freeze_manifest(out/'FROZEN_CAMPAIGN.json',frozen)
    from .cab_gpu import CABSD15GPU
    backend=CABSD15GPU(model_id=args.model_id,revision=args.model_revision,
                       reward_device='cpu',clip_device=args.clip_device,
                       steps=100,cfg=7.5,eta=1.,batch_size=args.batch_size,
                       local_files_only=args.offline)
    study=CABStudy(backend,out=out,budget=2600,N=16,
            selectors=[float(x) for x in args.slacks.split(',')])
    study.catalog.update(table)
    count=0
    for p in prompts:
        for seed in seeds:
            print('CAB UNIT',p['prompt_id'],seed,flush=True)
            study.run_unit(p['prompt'],p['prompt_id'],seed,methods,check_replay=True)
            count+=1
            decision=analyze_rows(study.all_rows,out/'analysis',bootstrap=args.bootstrap,
                                  minimum_prompts=args.min_prompts)
            jdump(out/'PHYSICAL_LEDGER.json',backend.metadata())
            print('CAB GATE',decision['status'],'PHYSICAL_NFE',backend.nfe,flush=True)
            if count>=args.max_units:
                return decision
            # Only stop when a complete prompt group is finished across seeds.
        if args.stop_on_futility and decision['status']=='HOLD_NO_CAB_SPECIFIC_PARETO_SIGNAL':
            return decision
    return decision


def analyze(args):
    rows=list(csv.DictReader(Path(args.results).open(encoding='utf-8')))
    x=analyze_rows(rows,args.out,bootstrap=args.bootstrap,minimum_prompts=args.min_prompts)
    print(json.dumps(x,indent=2,ensure_ascii=False));return x


def main():
    parser=argparse.ArgumentParser(description='CAB N16 vs Reward Branching/BoN26, TRAIN-only')
    sub=parser.add_subparsers(dest='cmd',required=True)
    for command in ('plan','run'):
        p=sub.add_parser(command)
        p.add_argument('--prompts',required=True)
        p.add_argument('--stage',choices=list(stages()),default='smoke')
        p.add_argument('--methods',default=None,help='Comma-separated predefined CAB/baseline methods')
        p.add_argument('--seeds',default='2026110101')
        p.add_argument('--slacks',default='0,.02,.05')
        p.add_argument('--out',default='runs/cab_n16')
        if command=='run':
            p.add_argument('--max-units',type=int,default=1)
            p.add_argument('--model-id',default='stable-diffusion-v1-5/stable-diffusion-v1-5')
            p.add_argument('--model-revision',default='451f4fe16113bff5a5d2269ed5ad43b0592e9a14')
            p.add_argument('--batch-size',type=int,default=1)
            p.add_argument('--clip-device',default='cpu')
            p.add_argument('--offline',action='store_true')
            p.add_argument('--approve-pilot',action='store_true')
            p.add_argument('--approve-expensive',action='store_true')
            p.add_argument('--stop-on-futility',action='store_true')
            p.add_argument('--bootstrap',type=int,default=3000)
            p.add_argument('--min-prompts',type=int,default=4)
    p=sub.add_parser('analyze')
    p.add_argument('--results',required=True);p.add_argument('--out',required=True)
    p.add_argument('--bootstrap',type=int,default=10000)
    p.add_argument('--min-prompts',type=int,default=4)
    args=parser.parse_args()
    return {'plan':plan,'run':run,'analyze':analyze}[args.cmd](args)

if __name__=='__main__':main()
