"""Synthetic CAB adapter. Outputs are NOT diffusion experimental results."""
import torch
from .fake import FakeAdapter

class FakeCABAdapter(FakeAdapter):
    def fork_action(self,states,slots,checkpoint,*,arm,strength=2.,window=6,dim=4,basis_seed=2031):
        x=self.fork(states,slots,checkpoint)
        parent_idx=int(float(states[0,0,0,0]))
        preferred_axis=parent_idx%dim
        # Stable synthetic response makes an actual action effect testable.
        if arm//2==preferred_axis:
            x[:,0,1,0] += (+.30 if arm%2==0 else -.30)*(strength/2)
        else:
            x[:,0,1,0] += (-.12 if arm%2==0 else +.07)*(strength/2)
        return x
