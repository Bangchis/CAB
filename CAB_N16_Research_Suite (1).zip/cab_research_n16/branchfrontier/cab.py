"""Contrastive Adaptive Branching (CAB) in stochastic DDIM noise-action space.

Research prototype. *Not* a proven improvement or a source of semantic labels.
Unlike an adaptive donor score, this module conditions the NEXT ACTION on
observed good/bad outcomes of earlier actions from comparable parent states.
It never sees the reward of the action that is currently being selected.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
import numpy as np
from .core import stable_seed, normalized

MODES = {'uniform_action', 'positive_action', 'negative_action',
         'contrastive_action', 'shuffled_negative'}


@dataclass(frozen=True)
class CABPolicy:
    name: str
    mode: str = 'contrastive_action'
    fork_index: int = 30
    branches: int = 14
    fresh: int = 0
    paired_neutral: bool = False  # one matched no-action fork per acted fork
    parent_pool: int = 4
    parent_temperature: float = .75
    parent_explore_floor: float = .15
    max_offspring: int = 4
    action_dim: int = 4                # +/- d action arms
    action_strength: float = 2.0       # l2 shift in each FP32 DDIM variance noise
    action_steps: int = 6             # first L steps after fork
    action_basis_seed: int = 2031
    action_bandwidth: float = .7
    action_temperature: float = 1.0
    positive_strength: float = 1.0
    negative_strength: float = 1.0
    duplicate_strength: float = .25
    action_explore_floor: float = .30
    min_observations: int = 3
    pseudo_count: float = 1.0
    feedback_scale: float = .15
    good_margin: float = .05
    bad_margin: float = .05
    near_duplicate: float = .025     # CLIP cosine distance, exploratory only
    cross_parent_strength: float = .25
    context_bandwidth: float = .25

    def cold_nfe(self, T=100, N=16):
        return int(N*T + self.branches*(2 if self.paired_neutral else 1)*(T-self.fork_index) + self.fresh*T)

    def validate(self, limit=2600, T=100, N=16):
        if self.mode not in MODES: raise ValueError('Unknown CAB mode')
        if not 0 < self.fork_index < T: raise ValueError('Invalid fork index')
        if self.branches < 0 or self.fresh < 0 or self.parent_pool < 1:
            raise ValueError('Invalid pool size')
        if self.max_offspring < 1 or self.parent_pool*self.max_offspring < self.branches:
            raise ValueError('Cannot allocate branches within offspring cap')
        if self.action_dim < 1 or self.action_dim > 8: raise ValueError('action_dim must be 1..8')
        if self.action_strength < 0 or self.action_steps < 1: raise ValueError('invalid action amplitude/window')
        if self.action_bandwidth <= 0 or self.action_temperature <= 0: raise ValueError('invalid action kernel/temperature')
        if self.pseudo_count <= 0 or self.feedback_scale <= 0 or self.context_bandwidth <= 0:
            raise ValueError('invalid estimation scale')
        if not 0 <= self.action_explore_floor <= 1 or not 0 <= self.parent_explore_floor <= 1:
            raise ValueError('invalid exploration mixture')
        if self.min_observations < 0 or self.cross_parent_strength < 0 or self.cross_parent_strength > 1:
            raise ValueError('invalid history/context settings')
        if self.cold_nfe(T,N) > limit:
            raise ValueError(f'{self.name} over budget: {self.cold_nfe(T,N)} > {limit}')
        return self

    def as_dict(self): return asdict(self)


def action_vector(arm: int, dim: int) -> np.ndarray:
    if not 0 <= arm < 2*dim: raise ValueError('invalid arm')
    x = np.zeros(dim, dtype=np.float64)
    x[arm // 2] = 1. if arm % 2 == 0 else -1.
    return x


def arm_kernel(arm: int, past_arm: int, dim: int, bandwidth: float):
    a=action_vector(arm,dim);b=action_vector(past_arm,dim)
    # Gaussian similarity on unit-length action codes: same=1, orthogonal<1, opposite<<1.
    return float(np.exp(-(1.-np.dot(a,b))/(bandwidth*bandwidth)))


def feedback_labels(reward: float, parent_reward: float, min_novelty: float, policy: CABPolicy):
    """Continuous signed evidence; a low score is NOT asserted to be a semantic error."""
    advantage=float(reward-parent_reward)
    good=float(np.clip((advantage-policy.good_margin)/policy.feedback_scale,0.,1.))
    bad=float(np.clip((-advantage-policy.bad_margin)/policy.feedback_scale,0.,1.))
    redundant=float(np.clip((policy.near_duplicate-min_novelty)/max(policy.near_duplicate,1e-6),0.,1.))
    return dict(advantage=advantage,positive=good,negative=bad,redundant=redundant)


def _stable_shuffle_negative(history, prompt_id, seed, slot):
    # Create a negative-feedback counterfactual; shuffle past negative outcomes
    # across past actions, without using any prospective branch reward.
    vals=[float(h['labels']['negative']) for h in history]
    if len(vals)<2: return vals
    rng=np.random.default_rng(stable_seed('shuffle_negative', prompt_id, seed, slot))
    return list(np.array(vals)[rng.permutation(len(vals))])


def arm_distribution(policy: CABPolicy, parent: int, root_features,
                     history: list[dict], *, prompt_id: int, seed: int, slot: int):
    """Compute q(a|parent, past outcomes) with separate attractive/repulsive memories.

    All history entries MUST predate `slot`; caller appends the current child
    only *after* selecting and completing it.
    """
    policy.validate()
    arm_count=2*policy.action_dim
    uniform=np.full(arm_count,1./arm_count)
    feats=normalized(np.asarray(root_features,dtype=float))
    if not 0<=parent<len(feats): raise ValueError('bad parent index')
    prev=list(history)
    if any(h['slot']>=slot for h in prev): raise ValueError('Future feedback leak')
    score=np.zeros(arm_count,float)
    pos=np.zeros(arm_count,float);neg=np.zeros(arm_count,float);dup=np.zeros(arm_count,float)
    evidence=np.zeros(arm_count,float)
    if policy.mode!='uniform_action' and len(prev)>=policy.min_observations:
        shuffled=_stable_shuffle_negative(prev,prompt_id,seed,slot) if policy.mode=='shuffled_negative' else None
        for a in range(arm_count):
            for j,h in enumerate(prev):
                hp=int(h['parent'])
                d=float(np.clip(1.-feats[parent]@feats[hp],0.,2.))
                ctx=1. if hp==parent else policy.cross_parent_strength*math.exp(-d/(policy.context_bandwidth**2))
                k=ctx*arm_kernel(a,int(h['arm']),policy.action_dim,policy.action_bandwidth)
                evidence[a]+=k
                pos[a]+=k*float(h['labels']['positive'])
                neg[a]+=k*(float(shuffled[j]) if shuffled is not None else float(h['labels']['negative']))
                dup[a]+=k*float(h['labels']['redundant'])
        # No pseudocount bias to a single champion. Posterior shrinkage turns
        # action scores off when the matching arm has no evidence.
        den=evidence+policy.pseudo_count
        pos=pos/den;neg=neg/den;dup=dup/den
        if policy.mode in ('positive_action','contrastive_action','shuffled_negative'):
            score+=policy.positive_strength*pos
        if policy.mode in ('negative_action','contrastive_action','shuffled_negative'):
            score-=policy.negative_strength*neg + policy.duplicate_strength*dup
    score=np.clip(score/policy.action_temperature,-30.,30.)
    ex=np.exp(score-np.max(score));p=ex/ex.sum()
    probs=(1-policy.action_explore_floor)*p+policy.action_explore_floor*uniform
    probs=probs/probs.sum()
    return probs,dict(scores=score.tolist(),positive_evidence=pos.tolist(),
                       negative_evidence=neg.tolist(),redundancy_evidence=dup.tolist(),
                       total_context_weight=evidence.tolist(),
                       tv_from_uniform=float(.5*np.abs(probs-uniform).sum()),
                       negative_memory_count=sum(h['labels']['negative']>0 for h in prev),
                       positive_memory_count=sum(h['labels']['positive']>0 for h in prev),
                       effective_history_count=len(prev),
                       activated=bool(len(prev)>=policy.min_observations and
                           policy.mode!='uniform_action' and np.max(score)-np.min(score)>1e-9))


def select_arm(policy, parent, root_features, history, prompt_id, seed, slot):
    p,diag=arm_distribution(policy,parent,root_features,history,
                             prompt_id=prompt_id,seed=seed,slot=slot)
    # Common random number across policies and variant modes, independent of
    # future outcome; different methods can select different arms using same u.
    u=float(np.random.default_rng(stable_seed('cab_u',prompt_id,seed,slot)).random())
    arm=int(np.searchsorted(np.cumsum(p),u,side='right'))
    arm=min(arm,len(p)-1)
    return arm,dict(**diag,chosen_arm=arm,chosen_probability=float(p[arm]),
                    probabilities=p.tolist(),selection_u=u)


def default_policies():
    out=[
        CABPolicy('cab_zero14','uniform_action',action_strength=0.),
        CABPolicy('cab_uniform14','uniform_action'),
        CABPolicy('cab_positive14','positive_action'),
        CABPolicy('cab_negative14','negative_action'),
        CABPolicy('cab_contrastive14','contrastive_action'),
        CABPolicy('cab_shuffle_negative14','shuffled_negative'),
        # Paired feedback tests actual arm effect vs a same-tape neutral continuation.
        # 7 matched pairs = 14 suffix rollouts, maintaining the 2580 cold-NFE ceiling.
        CABPolicy('cab_pair_uniform7','uniform_action',branches=7,paired_neutral=True),
        CABPolicy('cab_pair_positive7','positive_action',branches=7,paired_neutral=True),
        CABPolicy('cab_pair_negative7','negative_action',branches=7,paired_neutral=True),
        CABPolicy('cab_pair_shuffle7','shuffled_negative',branches=7,paired_neutral=True),
        CABPolicy('cab_pair_contrastive7','contrastive_action',branches=7,paired_neutral=True),
        CABPolicy('cab_uniform10b3f','uniform_action',branches=10,fresh=3),
        CABPolicy('cab_positive10b3f','positive_action',branches=10,fresh=3),
        CABPolicy('cab_shuffle10b3f','shuffled_negative',branches=10,fresh=3),
        CABPolicy('cab_contrastive10b3f','contrastive_action',branches=10,fresh=3),
        CABPolicy('cab_contrastive_cp20','contrastive_action',fork_index=20,branches=12,max_offspring=4),
        CABPolicy('cab_uniform_cp20','uniform_action',fork_index=20,branches=12,max_offspring=4),
        CABPolicy('cab_positive_cp20','positive_action',fork_index=20,branches=12,max_offspring=4),
        CABPolicy('cab_shuffle_cp20','shuffled_negative',fork_index=20,branches=12,max_offspring=4),
        CABPolicy('cab_contrastive_cp40','contrastive_action',fork_index=40,branches=16,max_offspring=4),
        CABPolicy('cab_uniform_cp40','uniform_action',fork_index=40,branches=16,max_offspring=4),
        CABPolicy('cab_positive_cp40','positive_action',fork_index=40,branches=16,max_offspring=4),
        CABPolicy('cab_shuffle_cp40','shuffled_negative',fork_index=40,branches=16,max_offspring=4),
    ]
    for p in out:p.validate()
    return out
