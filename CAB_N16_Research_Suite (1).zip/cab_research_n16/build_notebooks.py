from pathlib import Path
import nbformat as nbf
ROOT=Path(__file__).resolve().parent

def md(s):return nbf.v4.new_markdown_cell(s)
def code(s):return nbf.v4.new_code_cell(s)

def save(cells,name):
    nb=nbf.v4.new_notebook(cells=cells,metadata={
        'kernelspec':{'name':'python3','display_name':'Python 3','language':'python'},
        'language_info':{'name':'python','mimetype':'text/x-python','file_extension':'.py'}})
    nbf.validate(nb)
    nbf.write(nb,ROOT/'notebooks'/name)

main=[
md(r'''# CAB N16 — Contrastive Adaptive Branching | SD1.5 GPU

**Research question:** Can negative feedback on *previous continuation noise actions* improve branching beyond reward-only donors, positive-only action learning, and shuffled negatives, while maintaining CLIP diversity?

**BASELINE:** 26 independent roots ×100 = **2600 sample-NFE**; CAB: 16 roots ×100 +14 branches ×70 = **2580 sample-NFE**, output = Top16 of each method's pool. Shared caches are physical-compute savings, **not cold cost discounts**.

The previous pilot found a reward-only branching advantage but reduced CLIP diversity. This notebook does not claim to reproduce that pilot bitwise. It runs BoN and CAB with **the same manual GPU DDIM backend** for paired comparisons. It does **not** use reserved/TEST prompts or auto-run expensive stages.

CAB innovation: an *action-conditioned* memory for choosing **low-frequency DDIM noise-shift directions**, with positive/negative terminal feedback. Parent selection stays reward-only for an ablation that isolates learning in the noise-action distribution.'''),
md(r'''## 0 — Setup
Install CUDA-compatible PyTorch first. Follow the existing SD1.5 GPU runtime; never upgrade the frozen TPU venv. If this is a fresh environment, use the package's `requirements-gpu.txt`; restart kernel after install.'''),
code('''# Optional on a fresh GPU environment only:
# %pip install -r ../requirements-gpu.txt
import sys, json, subprocess, time, os
from pathlib import Path
import pandas as pd
import numpy as np
PROJECT=Path.cwd().resolve()
if not (PROJECT/'branchfrontier').is_dir(): PROJECT=PROJECT.parent
assert (PROJECT/'branchfrontier').is_dir(), 'Open notebook inside extracted cab_research_n16/notebooks/'
sys.path.insert(0,str(PROJECT))
from branchfrontier.cab import CABPolicy,default_policies
from branchfrontier.cab_cli import generated_grid,stages,load_prompts,analyze_rows
from branchfrontier.core import policy_manifest
print('PROJECT', PROJECT)
try:
 import torch
 print('torch',torch.__version__,'CUDA available:',torch.cuda.is_available())
except ImportError:
 print('Install PyTorch before CUDA stage')'''),
md(r'''## 1 — Fill a real TRAIN manifest and lock configuration
The provided template has two example prompts only. Use **development prompts**; do not put final/TEST into this notebook. Model revision and sampler are fixed. Every new experiment config should have a new output directory.'''),
code('''TRAIN_PROMPTS_PATH=PROJECT/'configs/TRAIN_PROMPTS_TEMPLATE.json'  # REPLACE with your TRAIN8
TRAIN=load_prompts(TRAIN_PROMPTS_PATH)
SEEDS=[2026110101,2026110102]             # Predeclare development seeds
OUT_SMOKE=PROJECT/'runs/cab_smoke'
OUT_PILOT=PROJECT/'runs/cab_pilot'
OUT_PROBE=PROJECT/'runs/cab_probe'
RUN_ACTION_PROBE=False                     # Costs extra true suffixes; not free
RUN_GPU_SMOKE=False
RUN_GPU_PILOT=False
RUN_SWEEP=False
APPROVE_EXPENSIVE=False
MIN_PROMPTS=4
print('TRAIN prompts',len(TRAIN),'pilot',stages()['pilot'])
assert all(p['split']=='TRAIN' for p in TRAIN)'''),
md(r'''## 2 — Algorithm and controls

For parent `i` and timestep `t`, action code `a∈{±e1,...,±e4}` shifts stochastic innovations for `action_steps` steps after fork. Each child produces a reward and CLIP image feature. Based on **earlier children only**, CAB computes action-conditioned `positive_score(a)` and `negative_score(a)`; the next action is drawn from:

\[
\pi(a\mid i,\mathcal H)=(1-\rho)\operatorname{softmax}_a\left(\frac{\beta P_i(a)-\gamma N_i(a)-\xi D_i(a)}{T_a}\right)+\rho\operatorname{Unif}(a).
\]

**Controls:** `reward14` (unshifted Gaussian suffix), `cab_uniform14` (same action space but no feedback), `cab_positive14`, `cab_negative14`, `cab_shuffle_negative14` (negative labels shuffled), `adaptive14` (old parent-level feedback), `bon26`.

Critically, `CAB` and `cab_uniform14` use the **same reward-only parent schedule**, and the base suffix noise for a given child slot is identical. A negative effect only counts if CAB beats positive-only and shuffled-negative, not merely BoN.'''),
code('''from branchfrontier.cab_cli import full_catalog
catalog=full_catalog()
methods=stages()['pilot']
costs=[]
for name in ['bon26']+methods:
 if name=='bon26':nfe=2600;description='26 independent images'
 else:
  p=catalog[name]
  nfe=p.cold_nfe() if isinstance(p,CABPolicy) else 1600+p.branches*(100-p.fork_index)+100*p.fresh
  description=(p.mode if isinstance(p,CABPolicy) else p.kind)
 costs.append(dict(method=name,cold_NFE=nfe,description=description))
display(pd.DataFrame(costs))
assert all(a['cold_NFE']<=2600 for a in costs)'''),
md(r'''## 3 — Run cheap CPU verification (no UNet)
The synthetic runner checks fixed-budget accounting, cache/resume, action distributions, and parent-schedule pairing. Its synthetic reward values **must not** be reported as image results.'''),
code('''p=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(PROJECT/'tests'),'-v'],
                 cwd=PROJECT,capture_output=True,text=True)
print(p.stdout[-2000:],p.stderr[-3000:]);assert p.returncode==0'''),
md(r'''## 4 — Produce a frozen plan without loading CUDA weights'''),
code('''plan_dir=PROJECT/'runs/PLAN_ONLY'
cmd=[sys.executable,'-m','branchfrontier.cab_cli','plan',
     '--prompts',str(TRAIN_PROMPTS_PATH),'--stage','smoke',
     '--seeds',str(SEEDS[0]),'--out',str(plan_dir)]
proc=subprocess.run(cmd,cwd=PROJECT,capture_output=True,text=True)
print(proc.stdout[-3000:]);assert proc.returncode==0,proc.stderr
print('Saved:',plan_dir/'PLAN.json')'''),
md(r'''## 5 — Optional paired action-effect probe before a pilot

This is an explicit diagnostic, **not** a BoN-matched method. From two parents, use the SAME checkpoint and noise tape for no-action, `+arm`, and `−arm`. The probe adds **420 physical NFE** after cached roots; root creation and replay are extra. If action effect is negligible or inconsistent, stop rather than sweeping more `negative_strength`.'''),
code('''if RUN_ACTION_PROBE:
    import torch
    assert torch.cuda.is_available(), 'GPU required'
    from branchfrontier.cab_gpu import CABSD15GPU
    from branchfrontier.cab_study import CABStudy
    from branchfrontier.cab_probe import paired_action_probe
    gpu=CABSD15GPU(root_seed=SEEDS[0],clip_device='cpu',batch_size=1)
    study=CABStudy(gpu,out=OUT_PROBE,selectors=(0.,))
    p=TRAIN[0]
    summary=paired_action_probe(study,p['prompt'],p['prompt_id'],SEEDS[0],
                         parents=2,checkpoint=30,arms=(0,1),strength=2.,window=6)
    display(pd.DataFrame(summary['rows']))
    print('physical diagnostic NFE',summary['actual_physical_nfe'])
    print('median |paired ΔIR|',summary['median_abs_reward_delta'],
          'median CLIP distance',summary['median_clip_delta'])
    del gpu,study
else:
    print('RUN_ACTION_PROBE=False; no GPU work')'''),
md(r'''## 6 — True GPU smoke: BoN26 + reward-only + uniform-action + CAB

Run 1 TRAIN prompt, one seed. After the smoke, check `analysis/CAB_DECISION.json`, per-slot probabilities and galleries. **The smoke cannot establish a gain**. It tests exact replay, correct NFE and non-trivial action influence.'''),
code('''if RUN_GPU_SMOKE:
    assert __import__('torch').cuda.is_available(), 'T4/CUDA runtime required'
    cmd=[sys.executable,'-m','branchfrontier.cab_cli','run',
         '--prompts',str(TRAIN_PROMPTS_PATH),'--stage','smoke',
         '--seeds',str(SEEDS[0]),'--max-units','1',
         '--out',str(OUT_SMOKE)]
    print('EXEC', ' '.join(cmd))
    subprocess.run(cmd,cwd=PROJECT,check=True)
else: print('RUN_GPU_SMOKE=False')'''),
code('''if (OUT_SMOKE/'all_rows.csv').exists():
    tab=pd.read_csv(OUT_SMOKE/'all_rows.csv')
    display(tab.query('selector=="top_ir"')[['method','best_ir','mean_top16_ir','clip_distance','cold_nfe','selected_branch_count']])
    print('Physical', (OUT_SMOKE/'PHYSICAL_LEDGER.json').read_text()[:1800] if (OUT_SMOKE/'PHYSICAL_LEDGER.json').exists() else 'not available')
    from glob import glob
    for f in glob(str(OUT_SMOKE/'unit_*/policy_cab_contrastive14.json')):
        trace=json.loads(Path(f).read_text())['traces']
        display(pd.DataFrame([dict(slot=t['slot'],parent=t['parent'],arm=t['arm'],
                          gain=t['labels']['advantage'],neg=t['labels']['negative'],
                          active=t['selection']['activated'],TV=t['selection']['tv_from_uniform'])
                          for t in trace]))
else: print('No GPU smoke outputs yet')'''),
md(r'''## 7 — Pilot (TRAIN only) with controls

Explicit approval flag. Keep **paired prompt/seed blocks**, not a collection of cherry-picked prompts. `CAB` must be compared to reward-only, action-uniform, positive-only and shuffled-negative under the exact same 2600-NFE ceiling. This may be expensive on a T4; inspect `PLAN.json` first. The runner never opens final/TEST automatically.'''),
code('''if RUN_GPU_PILOT:
    assert __import__('torch').cuda.is_available()
    assert len(TRAIN)>=MIN_PROMPTS, 'A 2-prompt template is not a pilot'
    cmd=[sys.executable,'-m','branchfrontier.cab_cli','run',
         '--prompts',str(TRAIN_PROMPTS_PATH),'--stage','pilot','--approve-pilot',
         '--seeds',','.join(map(str,SEEDS)),'--max-units',str(len(TRAIN)*len(SEEDS)),
         '--out',str(OUT_PILOT),'--bootstrap','10000','--min-prompts',str(MIN_PROMPTS),
         '--stop-on-futility']
    subprocess.run(cmd,cwd=PROJECT,check=True)
else: print('RUN_GPU_PILOT=False; no neural work')'''),
md(r'''## 8 — Read paired findings (prompt-cluster bootstrap)
The result may still be **no effect**. `Δ>0` against BoN alone is insufficient to claim that negative feedback helps. A change in the output selector does not create new images; it is an offline Pareto analysis.'''),
code('''run=OUT_PILOT if (OUT_PILOT/'all_rows.csv').exists() else OUT_SMOKE
if (run/'all_rows.csv').exists():
    rows=pd.read_csv(run/'all_rows.csv')
    chosen=rows.query('selector=="top_ir"')
    display(chosen.groupby('method')[['best_ir','mean_top16_ir','clip_distance','cab_action_active_rate','cab_action_avg_tv']].mean(numeric_only=True))
    x=json.loads((run/'analysis/CAB_DECISION.json').read_text())
    print('GATE:',x['status'])
    display(pd.DataFrame(x['candidates']))
    f=run/'analysis/paired_controls.csv'
    if f.exists(): display(pd.read_csv(f).query('metric=="mean_top16_ir"'))
else: print('No actual outputs yet')'''),
md(r'''## 9 — Predeclared sweep (NOT automatically launched)

Only if the pilot shows **action learning nonuniform AND CAB benefits beyond positive-only and shuffled negatives**. Sweep `strength∈{1,2,4}`, `γ_negative∈{0.5,1,2}`, `checkpoint∈{20,30,40}`. Every action strength/checkpoint gets **matched action-uniform and positive-only controls**. Gate expensive jobs with a fresh TRAIN output namespace. One configuration across 8 prompts ×2 seeds may already be expensive.'''),
code('''grid=generated_grid()  # 54 configurations; definitions only, nothing executed
sweep_path=PROJECT/'configs/SWEEP54_LOCKED.json'
sweep_path.write_text(json.dumps([p.as_dict() for p in grid],indent=2))
print('Wrote',len(grid),'predeclared candidate configurations:',sweep_path)
display(pd.DataFrame([dict(name=p.name,checkpoint=p.fork_index,
   mode=p.mode,strength=p.action_strength,negative=p.negative_strength,
   cold_NFE=p.cold_nfe()) for p in grid]).head(18))'''),
code('''# Example of a matched 3-way sweep slice. REVIEW it before setting RUN_SWEEP=True.
SWEEP_METHODS=['reward14','cab_uniform_cp30_s1','cab_positive_cp30_s1','cab_shuffle_cp30_s1','cab_cp30_s1_neg1']
SWEEP_OUT=PROJECT/'runs/cab_sweep_fresh_train'
if RUN_SWEEP:
    assert APPROVE_EXPENSIVE and __import__('torch').cuda.is_available()
    cmd=[sys.executable,'-m','branchfrontier.cab_cli','run','--stage','sweep',
       '--approve-expensive','--methods',','.join(SWEEP_METHODS),
       '--prompts',str(TRAIN_PROMPTS_PATH),'--seeds',','.join(map(str,SEEDS)),
       '--max-units',str(len(TRAIN)*len(SEEDS)),'--out',str(SWEEP_OUT)]
    subprocess.run(cmd,cwd=PROJECT,check=True)
else: print('RUN_SWEEP=False')'''),
md(r'''## 10 — CAB-Paired (causal action feedback, separate development run)

**Why:** Root-relative reward is a noisy label for an action: the root's terminal image used a different suffix tape. `CAB-Paired` runs an explicitly charged **no-action continuation from the SAME checkpoint, parent and suffix tape**, then compares the acted child to that neutral sibling. Thus each of 7 decision slots uses 2 suffix completions: **16×100 +7×2×70 = 2580 cold NFE**. All 14 suffix images belong to the final pool. The value of paired data is a hypothesis, not a guarantee; there are only seven action decisions.

Controls: `cab_pair_uniform7`, `cab_pair_positive7`, `cab_pair_negative7`, `cab_pair_shuffle7` against `cab_pair_contrastive7`, plus `reward14` and `bon26`. The paired methods all have the same branch-parent schedule and slot noise. They cannot use future action effects. They are compared as methods at equal cold NFE, NOT as seven paid edits with free neutral controls.'''),
code('''RUN_PAIRED=False     # Manual authorization, additional actual GPU work
PAIRED_OUT=PROJECT/'runs/cab_paired_fresh_train'
if RUN_PAIRED:
    assert APPROVE_EXPENSIVE and __import__('torch').cuda.is_available()
    assert len(TRAIN)>=MIN_PROMPTS
    methods=['reward14','cab_pair_uniform7','cab_pair_positive7',
             'cab_pair_negative7','cab_pair_contrastive7','cab_pair_shuffle7']
    cmd=[sys.executable,'-m','branchfrontier.cab_cli','run','--stage','paired',
         '--approve-expensive','--methods',','.join(methods),
         '--prompts',str(TRAIN_PROMPTS_PATH),'--seeds',','.join(map(str,SEEDS)),
         '--max-units',str(len(TRAIN)*len(SEEDS)),'--out',str(PAIRED_OUT)]
    print('EXEC', ' '.join(cmd))
    subprocess.run(cmd,cwd=PROJECT,check=True)
else: print('RUN_PAIRED=False; no GPU work')'''),
code('''if (PAIRED_OUT/'all_rows.csv').exists():
    df=pd.read_csv(PAIRED_OUT/'all_rows.csv')
    display(df.query('selector=="top_ir"').groupby('method')
            [['best_ir','mean_top16_ir','clip_distance','cold_nfe']].mean())
    info=json.loads((PAIRED_OUT/'analysis/CAB_DECISION.json').read_text())
    print(info['status']);display(pd.DataFrame(info['candidates']))
    print('Paired action effects are terminal child reward minus same-noise neutral continuation; no causal claim about prompt semantics.')
'''),
md(r'''## 11 — Decision rule and what constitutes paper-level evidence

**CAB mechanism passes development only if** negative action feedback generates a meaningful change in action probabilities and beats (at least) positive-only, shuffled-negative, uniform-action **and** old reward-only on held-out TRAIN blocks with enough distinct prompts; evaluate independent prompt fidelity and good-distinct later. Comparing `cab_contrastive14` to `bon26` alone cannot establish the negative contribution.

**Do not re-tune thresholds after seeing development results**. Keep final/TEST untouched. Publication claims require independent evaluation and prior-art review (noise trajectory search/contextual bandits and particle guidance are close).''')]

review=[
md(r'''# CAB — offline result analysis (no UNet)
Read an existing `runs/cab_pilot/all_rows.csv`. Paired differences are aggregated over seeds **inside prompt** and bootstrapped by prompt. `CLIP distance` is a proxy, NOT semantic correctness.'''),
code('''import sys,json
from pathlib import Path
import numpy as np,pandas as pd,matplotlib.pyplot as plt
ROOT=Path.cwd().resolve()
if not (ROOT/'branchfrontier').is_dir():ROOT=ROOT.parent
sys.path.insert(0,str(ROOT))
from branchfrontier.cab_cli import analyze_rows
RUN=ROOT/'runs/cab_pilot'
RESULTS=RUN/'all_rows.csv'
if not RESULTS.exists():
 print('No neural result at',RESULTS)
else:
 rows=pd.read_csv(RESULTS)
 display(rows.groupby(['selector','method'])[['best_ir','mean_top16_ir','clip_distance']].mean())'''),
code('''if RESULTS.exists():
 report=analyze_rows(rows.to_dict('records'),RUN/'OFFLINE_REVIEW',bootstrap=20000,minimum_prompts=4)
 print('Status:',report['status'])
 display(pd.DataFrame(report['candidates']))
 paired=pd.read_csv(RUN/'OFFLINE_REVIEW/paired_controls.csv')
 display(paired.query('baseline in ["bon26","reward14","cab_positive14","cab_shuffle_negative14"]'))'''),
code('''if RESULTS.exists():
 df=pd.read_csv(RUN/'OFFLINE_REVIEW/paired_controls.csv')
 R=df.query('baseline=="bon26" and metric=="mean_top16_ir"')
 D=df.query('baseline=="bon26" and metric=="clip_distance"')
 coords=R[['method','mean']].rename(columns={'mean':'reward_gain'}).merge(
         D[['method','mean']].rename(columns={'mean':'div_gain'}),on='method')
 fig,ax=plt.subplots(figsize=(9,6))
 for _,q in coords.iterrows():
  ax.scatter(q.reward_gain,q.div_gain);ax.annotate(q['method'],(q.reward_gain,q.div_gain),fontsize=8)
 ax.axhline(0,linewidth=1);ax.axvline(0,linewidth=1)
 ax.set_xlabel('Paired Δ mean Top16 ImageReward vs BoN26')
 ax.set_ylabel('Paired Δ CLIP cosine distance vs BoN26')
 ax.set_title('TRAIN development only')
 fig.tight_layout();fig.savefig(RUN/'OFFLINE_REVIEW/CAB_frontier.png',dpi=150)
 display(fig);plt.close(fig)'''),
md(r'''## Read causal diagnostics

For each method, `unit_*/policy_cab_*.json` contains per-slot action probabilities and chosen arm. Inspect activation rate, TV shift, number of positive and negative events. A policy always near uniform has **not** tested useful feedback even if its final reward differs by chance.'''),
code('''if RESULTS.exists():
 from glob import glob
 files=glob(str(RUN/'unit_*/policy_cab_contrastive14.json'))
 records=[]
 for f in files:
  obj=json.loads(Path(f).read_text())
  for h in obj['traces']:
   records.append(dict(unit=Path(f).parent.name,slot=h['slot'],arm=h['arm'],
      parent=h['parent'],reward=h['reward'],
      positive=h['labels']['positive'],negative=h['labels']['negative'],
      active=h['selection']['activated'],tv=h['selection']['tv_from_uniform']))
 if records:
  df=pd.DataFrame(records);display(df.groupby('unit')[['active','tv','positive','negative']].mean());display(df.head(20))
 else: print('No contrastive action logs found')'''),
md(r'''**No results in notebooks are fabricated.** The CPU fake tests validate code paths only; results from the true GPU sampler must be generated before making any superiority claim.''')]

save(main,'CAB_N16_GPU.ipynb')
save(review,'CAB_Offline_Review.ipynb')
print('notebooks created',[(p.name,p.stat().st_size) for p in (ROOT/'notebooks').glob('*.ipynb')])
